"""Online inference from each player's own observation and the full legal action mask."""
import numpy as np
import torch
import json
import hashlib,io
from pathlib import Path
from policy import Policy

def preferred_checkpoint(path):
    path=Path(path)
    marker=path.parent/'preferred-checkpoint.json'
    if marker.exists():
        selected=Path(json.loads(marker.read_text())['checkpoint'])
        if not selected.is_absolute():selected=marker.parent/selected
        if selected.is_file():return selected
    return path

def tensors(obs,encoding='riichienv-0.4.10-215x34-82'):
    seat=obs.player_id
    if any(hand for i,hand in enumerate(obs.hands) if i!=seat):
        raise ValueError('Concealed opponent hand reached an AI')
    assert obs.action_space_size==82
    actions={}
    for a in obs.legal_actions():actions.setdefault(a.encode(),[]).append(a)
    assert actions
    mask=np.zeros(82,dtype=np.bool_);mask[list(actions)]=True
    if encoding=='riichienv-0.4.10-215x34-82':x=np.frombuffer(obs.encode_extended(),dtype=np.float32).reshape(215,34).copy()
    else:
        from feature_v2 import ENCODING,encode
        if encoding!=ENCODING:raise ValueError('Unsupported feature encoding')
        x=encode(obs)
    assert np.isfinite(x).all()
    return x,mask,actions

def resolve(obs,actions,label):
    legal=actions[int(label)]
    # Equal copies of the same discard encode identically. Prefer the just
    # drawn copy when it is available, using only the player's visible hand.
    if label<=36 and not obs.forced_tedashi:
        own=obs.hands[obs.player_id]
        if own:
            for a in legal:
                if a.tile==own[-1]:return a
    return legal[0]

def load_policy(path):
    raw=Path(path).read_bytes()
    saved=torch.load(io.BytesIO(raw),map_location='cpu',weights_only=True)
    from feature_v2 import ENCODING,CHANNELS
    assert saved['encoding'] in ('riichienv-0.4.10-215x34-82',ENCODING)
    model=Policy(input_channels=CHANNELS if saved['encoding']==ENCODING else 215);model.encoding=saved['encoding'];model.load_state_dict(saved['policy']);model.eval()
    model.source_checkpoint=str(Path(path).resolve())
    model.source_sha256=hashlib.sha256(raw).hexdigest()
    model.profile=saved.get('selfplay',{}).get('profile','supervised')
    assert all(torch.isfinite(p).all() for p in model.parameters())
    return model

def choose(model,obs,stochastic=False):
    x,mask,actions=tensors(obs,getattr(model,'encoding','riichienv-0.4.10-215x34-82'))
    actions=retain_red_fives(obs,actions)
    mask[:]=False;mask[list(actions)]=True
    if mask.sum()==1:return resolve(obs,actions,np.flatnonzero(mask)[0])
    with torch.no_grad():
        logits=model(torch.from_numpy(x)[None],torch.from_numpy(mask)[None])[0]
        label=torch.distributions.Categorical(logits=logits).sample().item() if stochastic else logits.argmax().item()
    assert mask[label]
    return resolve(obs,actions,label)

def retain_red_fives(obs,actions):
    """Keep red five when its ordinary counterpart is also legally discardable.

    Same-type discards preserve shape and risk, but keeping red adds value.
    Never exchange a riichi player's locked hand or invent an illegal action.
    Apply before sampling so PPO labels/log probabilities match executed actions.
    """
    if obs.riichi_declared[obs.player_id]:return actions
    ordinary={a.tile//4 for group in actions.values() for a in group
              if json.loads(a.to_mjai())['type']=='dahai' and a.tile not in (16,52,88)}
    filtered={}
    for label,group in actions.items():
        kept=[a for a in group if not (json.loads(a.to_mjai())['type']=='dahai'
              and a.tile in (16,52,88) and a.tile//4 in ordinary)]
        if kept:filtered[label]=kept
    return filtered
