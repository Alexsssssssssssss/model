"""Canonical public-information features for dora retention and riichi defense."""
import collections
import numpy as np

ENCODING='riichienv-0.4.10-canonical224x34-82-v2'
CHANNELS=224

def dora_type(tile):
    kind=tile//4
    if kind<27:return kind//9*9+(kind%9+1)%9
    if kind<31:return 27+(kind-27+1)%4
    return 31+(kind-31+1)%3

def encode(obs):
    seat=obs.player_id
    assert not any(h for i,h in enumerate(obs.hands) if i!=seat)
    x=np.zeros((CHANNELS,34),dtype=np.float32)
    x[:215]=np.frombuffer(obs.encode_extended(),dtype=np.float32).reshape(215,34)
    # Native last-tedashi/riichi-discard groups use absolute opponent order.
    # Match all other channels' self/downstream/across/upstream ordering.
    absolute=[p for p in range(4) if p!=seat]
    relative=[(seat+i)%4 for i in range(1,4)]
    for offset in (197,206):
        native=x[offset:offset+9].copy().reshape(3,3,34)
        x[offset:offset+9]=native[[absolute.index(p) for p in relative]].reshape(9,34)
    bonuses=collections.Counter(dora_type(t) for t in obs.dora_indicators)
    for tile,count in bonuses.items():x[215,tile]=count
    if obs.drawn_tile is not None and any(a.encode()<=36 for a in obs.legal_actions()) and obs.drawn_tile in obs.hands[seat]:x[223,obs.drawn_tile//4]=1
    for i in range(4):
        p=(seat+i)%4
        held=list(obs.hands[p]) if p==seat else []
        for meld in obs.melds[p]:held.extend(meld.tiles)
        # A discarded dora is no longer part of that player's hand value.
        x[55+i,:]=sum(bonuses[t//4] for t in held)/12
        if p==seat:
            for tile in held:x[216,tile//4]+=bonuses[tile//4]+int(tile in (16,52,88))
    for i,p in enumerate(relative):
        if not obs.riichi_declared[p]:continue
        river={tile//4 for tile in obs.discards[p]}
        for tile in river:x[217+i,tile]=1
        # Suji is a contextual risk cue, not a guaranteed safe-tile rule.
        # Middle tiles need both relevant outer suji tiles to be visible.
        for tile in range(27):
            rank=tile%9
            if rank<3:suji=tile+3 in river
            elif rank>=6:suji=tile-3 in river
            else:suji=tile-3 in river and tile+3 in river
            if suji:x[220+i,tile]=1
    assert np.isfinite(x).all()
    return x
