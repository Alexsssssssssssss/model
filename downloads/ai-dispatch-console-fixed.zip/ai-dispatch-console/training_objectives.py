"""User-specified terminal placement utility; original units retained in metadata."""
OBJECTIVE_VERSION='placement-20261012-user-v2'
UTILITIES={
    'first_place':[60,10,-25,-45],
    'balanced':[40,20,0,-60],
    'avoid_fourth':[40,20,0,-70],
}

def terminal_reward(profile,rank):
    if profile not in UTILITIES or rank not in (1,2,3,4):
        raise ValueError('Invalid placement objective or rank')
    utility=UTILITIES[profile]
    return utility[rank-1]/max(abs(v) for v in utility)
