"""Auditable round-based Mahjong rates; rank statistics use half-games."""
from collections import Counter

DEFINITIONS={
 'open_rate':'至少一次吃、碰或大明杠的局数 / 总局数；暗杠不算副露',
 'riichi_rate':'立直成立（reach_accepted）的局数 / 总局数；宣言即放铳不算成立',
 'win_rate':'和牌局数 / 总局数',
 'deal_in_rate':'放铳局数 / 总局数；双响或三响放铳计一局，失点合计',
 'tsumo_rate':'自摸和牌局数 / 总局数',
 'ron_rate':'荣和局数 / 总局数',
 'chase_riichi_rate':'已有对手立直时才成立立直的局数 / 自己立直成立局数',
 'riichi_declaration_deal_in_rate':'立直宣言牌直接放铳、导致立直未成立的局数 / 立直宣言局数',
 'average_win_points':'和牌得点合计 / 和牌局数，包含事件结算中的本场和供托',
 'average_deal_in_loss':'放铳失点合计 / 放铳局数',
 'mean_rank':'终局顺位合计 / 完成半庄数；不与逐局指标混用',
 'coverage':'逐局指标只覆盖保存了完整事件及统计的半庄；历史缺失值显示为空',
}

def analyze(events,final_scores=None,final_ranks=None):
    result=[Counter() for _ in range(4)];hand=None;initial=None;derived=None
    def finish():
        nonlocal hand
        if hand is None:return
        assert hand['ended'],'A round has no terminal result'
        for p,row in enumerate(result):
            row['hands']+=1
            for field in ('open','kan','riichi','declared','win','deal_in','tsumo','ron','draw','chase','riichi_win','open_win','riichi_deal_in'):
                row[field+'_hands']+=int(hand[field][p])
            row['riichi_declaration_deal_in_hands']+=int(hand['declared'][p] and not hand['riichi'][p] and hand['deal_in'][p])
            row['win_points']+=hand['win_points'][p];row['deal_in_points']+=hand['deal_in_points'][p]
        hand=None
    for event in events:
        kind=event['type']
        if kind=='start_kyoku':
            finish();scores=event.get('scores',[25000]*4)
            if initial is None:initial=list(scores);derived=list(scores)
            hand={f:[False]*4 for f in ('open','kan','riichi','declared','win','deal_in','tsumo','ron','draw','chase','riichi_win','open_win','riichi_deal_in')}
            hand.update(win_points=[0]*4,deal_in_points=[0]*4,ended=False)
        elif kind=='end_kyoku':finish()
        elif kind=='end_game':
            if final_scores is None and 'scores' in event:final_scores=event['scores']
        elif hand is not None:
            actor=event.get('actor')
            if kind in ('chi','pon','daiminkan'):hand['open'][actor]=True
            if kind in ('ankan','kakan','daiminkan'):hand['kan'][actor]=True
            if kind=='reach':hand['declared'][actor]=True
            if kind=='reach_accepted':
                hand['chase'][actor]=any(v for p,v in enumerate(hand['riichi']) if p!=actor)
                if not hand['riichi'][actor]:derived[actor]-=1000
                hand['riichi'][actor]=True
            if kind in ('hora','ryukyoku'):
                hand['ended']=True
                delta=event.get('deltas')
                if delta is not None:derived=[s+d for s,d in zip(derived,delta)]
                elif 'scores' in event:derived=list(event['scores'])
                if kind=='ryukyoku':hand['draw']=[True]*4
                else:
                    target=event['target'];tsumo=actor==target
                    hand['win'][actor]=True;hand['tsumo' if tsumo else 'ron'][actor]=True
                    hand['riichi_win'][actor]=hand['riichi'][actor];hand['open_win'][actor]=hand['open'][actor]
                    if delta is not None:hand['win_points'][actor]+=max(0,delta[actor])
                    if not tsumo:
                        hand['deal_in'][target]=True;hand['riichi_deal_in'][target]=hand['riichi'][target]
                        if delta is not None:hand['deal_in_points'][target]+=max(0,-delta[target])
    finish()
    assert initial is not None
    final_scores=final_scores if final_scores is not None else derived
    if final_ranks is None:
        order=sorted(range(4),key=lambda p:(-final_scores[p],p));final_ranks=[order.index(p)+1 for p in range(4)]
    for p,row in enumerate(result):
        row.update(half_games=1,rank_sum=final_ranks[p],net_points=final_scores[p]-initial[p])
        row['rank_'+str(final_ranks[p])]=1
    return [dict(r) for r in result]

def rates(counts):
    hands=counts.get('hands',0);games=counts.get('half_games',0)
    def ratio(n,d):return counts.get(n,0)/d if d else None
    result=dict(half_games=games,hands=hands,mean_rank=ratio('rank_sum',games),mean_net_points=ratio('net_points',games))
    for metric,key in [('open_rate','open_hands'),('riichi_rate','riichi_hands'),('win_rate','win_hands'),('deal_in_rate','deal_in_hands'),('tsumo_rate','tsumo_hands'),('ron_rate','ron_hands')]:result[metric]=ratio(key,hands)
    for rank in range(1,5):result['rank_'+str(rank)+'_rate']=ratio('rank_'+str(rank),games)
    result.update(chase_riichi_rate=ratio('chase_hands',counts.get('riichi_hands',0)),
                  riichi_declaration_rate=ratio('declared_hands',hands),
                  riichi_declaration_deal_in_rate=ratio('riichi_declaration_deal_in_hands',counts.get('declared_hands',0)),
                  average_win_points=ratio('win_points',counts.get('win_hands',0)),
                  average_deal_in_loss=ratio('deal_in_points',counts.get('deal_in_hands',0)))
    return result
