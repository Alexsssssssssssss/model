"""Portable full-action PPO update; no platform transport or account access."""
import numpy as np
import torch

def forward(model,value,x,mask):
    h=model.encoder(x);logits=model.head(h).masked_fill(~mask,-1e9)
    return logits,value(h.flatten(1)).squeeze(1)

def optimize(model,value,anchor,optimizer,rows,returns,rng):
    x=np.stack([r[0] for r in rows]);mask=np.stack([r[1] for r in rows]);labels=np.array([r[2] for r in rows]);oldlp=np.array([r[3] for r in rows]);oldv=np.array([r[4] for r in rows]);target=np.array(returns,dtype=np.float32)
    advantage=target-oldv;advantage=(advantage-advantage.mean())/(advantage.std()+1e-6)
    losses=[];kl=[];updates=0;stop=False
    model.train();value.train()
    for _ in range(3):
        order=rng.permutation(len(rows))
        for start in range(0,len(rows),128):
            ix=order[start:start+128];tx=torch.from_numpy(x[ix].astype(np.float32));tm=torch.from_numpy(mask[ix]);ty=torch.from_numpy(labels[ix]);ta=torch.from_numpy(advantage[ix].astype(np.float32));tr=torch.from_numpy(target[ix]);tlp=torch.from_numpy(oldlp[ix].astype(np.float32))
            logits,v=forward(model,value,tx,tm);dist=torch.distributions.Categorical(logits=logits);lp=dist.log_prob(ty);ratio=(lp-tlp).exp()
            policy_loss=-torch.minimum(ratio*ta,ratio.clamp(.8,1.2)*ta).mean()
            with torch.no_grad():ref=anchor(tx,tm);ref_log=torch.log_softmax(ref,1);ref_prob=ref_log.exp()
            imitation_kl=(ref_prob*(ref_log-torch.log_softmax(logits,1))).sum(1).mean()
            loss=policy_loss+.5*torch.nn.functional.mse_loss(v,tr)-.005*dist.entropy().mean()+.1*imitation_kl
            assert torch.isfinite(loss)
            optimizer.zero_grad(set_to_none=True);loss.backward();torch.nn.utils.clip_grad_norm_([*model.parameters(),*value.parameters()],.5);optimizer.step()
            losses.append(loss.item());kl.append(imitation_kl.item());updates+=1
            approx_kl=((ratio-1)-(lp-tlp)).mean().item()
            if approx_kl>.04:stop=True;break
        if stop:break
    assert all(torch.isfinite(p).all() for p in [*model.parameters(),*value.parameters()])
    return dict(loss=float(np.mean(losses)),anchor_kl=float(np.mean(kl)),optimizer_steps=updates,kl_early_stop=stop)

