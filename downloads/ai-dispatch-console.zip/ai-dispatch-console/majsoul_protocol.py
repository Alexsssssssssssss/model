"""Dynamic Liqi protobuf codec and RPC transport. No third-party policy weights."""
import asyncio,json,struct
from pathlib import Path
from google.protobuf import descriptor_pb2,descriptor_pool,message_factory,json_format
from websockets.asyncio.client import connect
BASE=Path(__file__).resolve().parent
SCALARS={'double':1,'float':2,'int64':3,'uint64':4,'int32':5,'fixed64':6,'fixed32':7,'bool':8,'string':9,'bytes':12,'uint32':13,'sfixed32':15,'sfixed64':16,'sint32':17,'sint64':18}
class Codec:
 def __init__(self,path=BASE/'codec/liqi.json',live=False):
  self.schema=json.loads(Path(path).read_text())['nested']['lq']['nested'];self.kinds={}
  if live:
   # Unity adds platform at wire field 6; the retained public Liqi schema predates it.
   self.schema['ReqRequestConnection']['fields']['platform']=dict(type='string',id=6)
  def inventory(nodes,prefix):
   for name,node in nodes.items():
    full=prefix+'.'+name
    if 'fields' in node or 'values' in node:self.kinds[full]='message' if 'fields' in node else 'enum'
    inventory(node.get('nested',{}),full)
  inventory(self.schema,'lq');file=descriptor_pb2.FileDescriptorProto(name='liqi.proto',package='lq',syntax='proto3')
  def fill(nodes,dest,prefix):
   for name,node in nodes.items():
    full=prefix+'.'+name
    if 'values' in node:
     e=dest.enum_type.add(name=name);seen=set()
     for key,num in node['values'].items():
      e.value.add(name=key,number=num)
      if num in seen:e.options.allow_alias=True
      seen.add(num)
    elif 'fields' in node:
     m=dest.message_type.add(name=name) if hasattr(dest,'message_type') else dest.nested_type.add(name=name)
     for key,field in node['fields'].items():
      f=m.field.add(name=key,number=field['id'],label=3 if field.get('rule')=='repeated' else 1)
      t=field['type']
      if t in SCALARS:f.type=SCALARS[t]
      else:
       scopes=full.split('.')
       while scopes and '.'.join(scopes)+'.'+t not in self.kinds:scopes.pop()
       resolved=('.'.join(scopes)+'.'+t) if scopes else t.lstrip('.')
       if resolved not in self.kinds:raise ValueError('Unresolved protocol type '+t)
       f.type=11 if self.kinds[resolved]=='message' else 14;f.type_name='.'+resolved
     fill(node.get('nested',{}),m,full)
  fill(self.schema,file,'lq');self.pool=descriptor_pool.DescriptorPool();self.pool.Add(file)
 def cls(self,name):return message_factory.GetMessageClass(self.pool.FindMessageTypeByName(name if name.startswith('lq.') else 'lq.'+name))
 def encode(self,name,data):
  m=self.cls(name)();json_format.ParseDict(data,m,ignore_unknown_fields=False);return m.SerializeToString()
 def decode(self,name,data):
  m=self.cls(name)();m.ParseFromString(data);return json_format.MessageToDict(m,preserving_proto_field_name=True,always_print_fields_with_no_presence=True,use_integers_for_enums=True)
 def method(self,name):
  service,method=name.removeprefix('.lq.').split('.');return self.schema[service]['methods'][method]

class SoulRPCError(RuntimeError):
 def __init__(self,method,code):
  self.method=method;self.code=code
  super().__init__('雀魂接口 '+method.rsplit('.',1)[-1]+' 返回错误码 '+str(code)+('（客户端版本或Web平台握手不被接受）' if code==151 else ''))

class RPC:
 def __init__(self,codec):self.codec=codec;self.index=0;self.pending={};self.notifications=asyncio.Queue();self.ws=None;self.reader=None;self.closing=False
 async def open(self,url):
  if not url.startswith('wss://'):raise ValueError('只接受加密雀魂网关')
  self.ws=await connect(url,origin='https://game.maj-soul.com',open_timeout=20);self.reader=asyncio.create_task(self.read());return self
 async def read(self):
  error_type='CleanWebSocketClosure'
  try:
   async for raw in self.ws:
    if not isinstance(raw,bytes):raise ValueError('Unexpected nonbinary Liqi packet')
    kind=raw[0];offset=3 if kind in (2,3) else 1;wrapper=self.codec.cls('Wrapper')();wrapper.ParseFromString(raw[offset:])
    if kind==3:
     index=struct.unpack('<H',raw[1:3])[0];entry=self.pending.pop(index,None)
     if entry:
      typ,future=entry
      if not future.done():future.set_result(self.codec.decode(typ,wrapper.data))
    elif kind==1:
     name=wrapper.name.removeprefix('.');data=self.codec.decode(name,wrapper.data)
     await self.notifications.put((name,data))
    else:raise ValueError('Unsupported Liqi packet')
  except asyncio.CancelledError:
   error_type='CancelledError'
   raise
  except Exception as exc:
   error_type=type(exc).__name__
  finally:
   for _,future in self.pending.values():
    if not future.done():future.set_exception(ConnectionError('雀魂连接已结束'))
   self.pending.clear()
   if not self.closing:await self.notifications.put(('connection_closed',dict(error_type=error_type,close_code=getattr(self.ws,'close_code',None))))
 async def call(self,name,data=None):
  meta=self.codec.method(name);self.index=(self.index+1)%65536;index=self.index;future=asyncio.get_running_loop().create_future();self.pending[index]=(meta['responseType'],future)
  wrapper=self.codec.cls('Wrapper')(name=name,data=self.codec.encode(meta['requestType'],data or {}))
  try:
   await self.ws.send(b'\x02'+struct.pack('<H',index)+wrapper.SerializeToString());reply=await asyncio.wait_for(future,30)
   if reply.get('error',{}).get('code'):raise SoulRPCError(name,reply['error']['code'])
   return reply
  finally:self.pending.pop(index,None)
 async def close(self):
  self.closing=True
  if self.ws:await self.ws.close()
  if self.reader:self.reader.cancel();await asyncio.gather(self.reader,return_exceptions=True)
