"""Resolve CN Unity WebGL package and resource versions from official assets."""
import json,re,time,urllib.request,urllib.error,warnings,ssl,socket,threading
from urllib.parse import urlsplit
from pathlib import PurePosixPath
BASE='https://game.maj-soul.com'

class PublicFetchError(ConnectionError):
 def __init__(self,url,exc,attempts):
  parsed=urlsplit(url);endpoint=parsed.scheme+'://'+str(parsed.hostname)+parsed.path
  reason=getattr(exc,'reason',exc)
  self.details=dict(endpoint=endpoint,attempts=attempts,error_type=type(reason).__name__,winerror=getattr(reason,'winerror',None),proxy_configured=bool(urllib.request.getproxies().get('https')))
  if isinstance(reason,ssl.SSLCertVerificationError):hint='HTTPS证书验证失败，请检查代理证书或系统证书；未关闭证书验证'
  elif getattr(reason,'winerror',None)==10061 or isinstance(reason,ConnectionRefusedError):hint='连接被拒绝，请检查本机代理是否启动、端口是否有效，以及网络连接'
  elif isinstance(reason,(TimeoutError,socket.timeout)):hint='连接或TLS握手超时，请检查网络或代理'
  else:hint='无法读取官方配置，请检查网络或代理'
  super().__init__('雀魂官方配置请求失败：'+endpoint+'；'+hint+'（尝试'+str(attempts)+'次）')

def read_public(url):
 sep='&' if '?' in url else '?'
 req=urllib.request.Request(url+sep+'randv='+str(time.time_ns()),headers={'User-Agent':'Mozilla/5.0','Cache-Control':'no-cache','If-Modified-Since':'0'})
 for attempt in range(1,4):
  try:
   with urllib.request.urlopen(req,timeout=35) as response:data=response.read(16*1024*1024+1)
   if len(data)>16*1024*1024:raise ValueError('雀魂版本配置超过读取上限')
   return data
  except (urllib.error.URLError,OSError) as exc:
   reason=getattr(exc,'reason',exc)
   retry=not isinstance(reason,ssl.SSLCertVerificationError) and (not isinstance(exc,urllib.error.HTTPError) or exc.code in (408,429,500,502,503,504))
   if attempt==3 or not retry:raise PublicFetchError(url,exc,attempt) from exc
   time.sleep(attempt)

_VERSION_LOCK=threading.Lock()
_VERSION_CACHE=None
_VERSION_TIME=0.0

def bundle_objects(raw):
 import UnityPy
 from UnityPy.exceptions import UnityVersionFallbackWarning
 # Public bundles strip the engine version to 0.0.0; the official build is Unity 2022.3.
 UnityPy.config.FALLBACK_UNITY_VERSION='2022.3.62f2'
 with warnings.catch_warnings():
  warnings.simplefilter('ignore',UnityVersionFallbackWarning)
  return list(UnityPy.load(raw).objects)

def _resolve_client_version():
 html=read_public(BASE+'/1/').decode('utf-8')
 match=re.search(r'productVersion\s*:\s*[\"\'](\d+\.\d+\.\d+)[\"\']',html)
 if 'createUnityInstance' not in html or not match:raise ValueError('无法确认雀魂现用Unity客户端版本，已停止；不会使用旧version.json替代')
 package=match.group(1)
 manifest=read_public(BASE+'/assetbundles/ASTC/bundle_info_so.majset')
 info=None
 for obj in bundle_objects(manifest):
  if obj.type.name=='MonoBehaviour':
   tree=obj.read_typetree()
   if 'assetInfos' in tree and 'bundleInfos' in tree:info=tree;break
 if info is None:raise ValueError('雀魂资源索引格式不支持')
 matches=[a for a in info['assetInfos'] if a['assetPath'].replace('\\','/').endswith('/docs_version/version.json')]
 if len(matches)!=1:raise ValueError('未唯一定位雀魂资源版本配置')
 name=info['bundleInfos'][matches[0]['ownerBundleIndex']]['name']
 if PurePosixPath(name).name!=name or not re.fullmatch(r'[A-Za-z0-9_.-]+\.majset',name):raise ValueError('雀魂版本资源文件名无效')
 raw=read_public(BASE+'/assetbundles/ASTC/'+name);resource=None
 for obj in bundle_objects(raw):
  if obj.type.name=='TextAsset':
   asset=obj.read()
   if asset.m_Name=='version':
    data=json.loads(asset.m_Script)
    if data.get('platform')=='WebGL':resource=data.get('version')
 if not isinstance(resource,str) or not re.fullmatch(r'\d+\.\d+\.\d+',resource):raise ValueError('雀魂资源版本配置无效')
 return dict(resource=resource,package=package,client_version_string='WebGL_2022-'+resource,version_bundle=name)

def client_version_string(version):return version['client_version_string']


def resolve_client_version():
 global _VERSION_CACHE,_VERSION_TIME
 with _VERSION_LOCK:
  if _VERSION_CACHE is not None and time.monotonic()-_VERSION_TIME<60:return dict(_VERSION_CACHE)
  version=_resolve_client_version();_VERSION_CACHE=dict(version);_VERSION_TIME=time.monotonic();return version
