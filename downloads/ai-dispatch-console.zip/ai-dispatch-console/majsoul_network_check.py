"""Official public endpoints only: no account, password, login or game request."""
import asyncio,json,time,urllib.request
from pathlib import Path
from majsoul_live import gateway
from majsoul_protocol import Codec,RPC
from majsoul_version import PublicFetchError
from urllib.parse import urlsplit
async def check():
 report={'credentials_used':False,'https_proxy_configured':bool(urllib.request.getproxies().get('https')),'stage':'public_config','status':'running'};rpc=None
 try:
  version,route=await asyncio.to_thread(gateway);report.update(client_version=version,gateway=route,stage='websocket_handshake')
  rpc=RPC(Codec(live=True));await rpc.open(route+'/gateway')
  response=await rpc.call('.lq.Route.requestConnection',dict(type=1,route_id=urlsplit(route).hostname.split('.')[0],timestamp=int(time.time()),platform='Web'))
  if response.get('result')!=1:raise RuntimeError('线路握手未接受')
  report.update(status='passed',stage='public_config_and_websocket_connected',note='Public connectivity only; no account login, room entry, or game tested')
 except Exception as exc:
  report.update(status='failed',error_type=type(exc).__name__)
  if isinstance(exc,PublicFetchError):report.update(network_failure=exc.details,error=str(exc))
  else:report['note']='WebSocket连接或握手失败；没有提交登录或对局请求'
 finally:
  if rpc:await rpc.close()
 Path('majsoul-network-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2));return report
if __name__=='__main__':asyncio.run(check())
