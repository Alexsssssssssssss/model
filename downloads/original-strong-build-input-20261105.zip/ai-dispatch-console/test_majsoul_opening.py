"""Opening-window and terminal-result regressions; no real account used.

Four anonymous opening hands come from the uploaded failure diagnostic. The
transport explicitly models an opening lockout; passing it is not live-server
proof. Actual model weights, protobuf and native states are used.
"""
import asyncio
import base64
import copy
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import majsoul_live as m
from majsoul_protocol import Codec, RPC, SoulRPCError
import original_strong_live as original

B=Path(__file__).resolve().parent
CP=B/'models/original-strong.json'
CASES=[
 dict(tiles=['5p','3s','5m','8m','8s','2m','1s','8s','4z','3p','6m','6m','1z','2z'],
      chang=0,ju=1,ben=0,liqibang=0,scores=[21000,23000,33000,23000],doras=['6z'],
      expected='2z',old_actual='4z'),
 dict(tiles=['6p','9s','1p','3p','6s','2p','1m','2m','9m','3m','7p','0p','5s','1m'],
      chang=1,ju=1,ben=0,liqibang=0,scores=[11900,30400,38000,19700],doras=['2m'],
      expected='9s',old_actual='9s'),
 dict(tiles=['5z','1m','7p','0p','0s','1z','6z','5s','1m','6m','4z','2m','3p','7m'],
      chang=1,ju=1,ben=1,liqibang=0,scores=[7900,42400,34000,15700],doras=['7p'],
      expected='4z',old_actual='6z'),
 dict(tiles=['1z','7m','9p','9p','1m','2z','1s','3p','6m','0p','2z','6s','3p','5m'],
      chang=1,ju=1,ben=2,liqibang=1,scores=[6900,44400,33000,14700],doras=['1m'],
      expected='1s',old_actual='2z')]


class Clock:
    def __init__(self):self.now=100.;self.waits=[]
    def monotonic(self):return self.now
    async def sleep(self,seconds):
        self.waits.append(seconds);self.now+=seconds


class OpeningChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        original.prepare_original_model(CP)
        cls.codec=Codec(live=True)

    def client(self,seat=1):
        c=m.SoulRoomClient('synthetic','synthetic','balanced',CP,12345,output=B)
        c.policy=m.SoulPolicy(CP,seat)
        c.policy.event(dict(type='start_game',names=['player']*4))
        return c

    def packet(self,case):
        data={k:copy.deepcopy(v) for k,v in case.items() if k not in ('expected','old_actual')}
        data['operation']=dict(seat=data['ju'],operation_list=[dict(type=1)])
        return self.codec.decode('ActionNewRound',self.codec.encode('ActionNewRound',data))

    def test_captured_four_openings_wait_then_execute_the_model_tile(self):
        async def run(case):
            clock=Clock();c=self.client();calls=[];started=clock.now
            async def call(method,request):
                # An early RPC acknowledges but does not apply the input.
                applied=request['tile'] if clock.now-started>=3. else case['old_actual']
                calls.append((clock.now,dict(request),applied))
            c.game=SimpleNamespace(call=call)
            with patch.object(m,'time',clock),patch.object(m.asyncio,'sleep',clock.sleep):
                await c.action('ActionNewRound',self.packet(case),received_at=started)
                record=c.diagnostic['dealer_first_discards'][-1]
                self.assertEqual(record['request']['tile'],case['expected'])
                self.assertFalse(record['request']['moqie'])
                self.assertGreaterEqual(calls[0][0]-started,3.)
                self.assertEqual(calls[0][2],case['expected'])
                await c.action('ActionDiscardTile',dict(seat=1,tile=calls[0][2],moqie=False))
                self.assertTrue(record['notification_matches_requested_tile'])
                self.assertEqual(record['status'],'discard_notification_received')
                self.assertTrue(record['rpc_ack_does_not_confirm_discard'])
        for case in CASES:
            with self.subTest(round_wind=case['chang'],honba=case['ben']):asyncio.run(run(case))

    def test_an_aged_opening_does_not_add_another_three_seconds(self):
        async def run():
            clock=Clock();c=self.client();calls=[]
            async def call(method,request):calls.append(clock.now)
            c.game=SimpleNamespace(call=call)
            with patch.object(m,'time',clock),patch.object(m.asyncio,'sleep',clock.sleep):
                await c.action('ActionNewRound',self.packet(CASES[0]),received_at=96.)
            self.assertEqual(calls,[100.])
            self.assertEqual(clock.waits,[0])
            record=c.diagnostic['dealer_first_discards'][-1]
            self.assertEqual(record['notification_queue_seconds'],4.)
            self.assertEqual(record['opening_wait_seconds'],0.)
        asyncio.run(run())

    def test_ordinary_draw_has_no_opening_wait(self):
        async def run():
            clock=Clock();c=self.client();calls=[]
            async def call(method,request):calls.append(clock.now)
            c.game=SimpleNamespace(call=call)
            with patch.object(m,'time',clock),patch.object(m.asyncio,'sleep',clock.sleep):
                await c.action('ActionNewRound',self.packet(CASES[0]))
                req=c.diagnostic['dealer_first_discards'][-1]['request']
                await c.action('ActionDiscardTile',dict(seat=1,tile=req['tile'],moqie=False))
                clock.waits=[];before=clock.now
                await c.action('ActionDealTile',dict(seat=1,tile='9p',operation=dict(seat=1,operation_list=[dict(type=1)])))
                self.assertEqual(clock.now,before)
                self.assertEqual(clock.waits,[0])
                self.assertEqual(len(calls),2)
        asyncio.run(run())

    def test_initial_synthetic_draw_is_never_sent_as_moqie(self):
        async def run():
            clock=Clock();c=self.client();calls=[]
            async def call(method,request):calls.append(request)
            c.game=SimpleNamespace(call=call)
            with patch.object(m,'time',clock),patch.object(m.asyncio,'sleep',clock.sleep),\
                 patch.object(c.policy,'choose',return_value=dict(type=7,tile='2z',moqie=True)):
                await c.action('ActionNewRound',self.packet(CASES[0]))
            self.assertEqual(calls,[dict(type=7,tile='2z',moqie=False)])
            self.assertTrue(c.diagnostic['dealer_first_discards'][-1]['engine_request']['moqie'])
        asyncio.run(run())

    def test_terminal_message_presence_and_draw_bool_defaults(self):
        for name in ('ActionHule','ActionLiuJu'):
            absent=self.codec.decode(name,self.codec.encode(name,{}))
            present=self.codec.decode(name,self.codec.encode(name,dict(gameend={})))
            self.assertFalse(m.has_game_end(absent))
            self.assertTrue(m.has_game_end(present))
            self.assertTrue(m.has_game_end(dict(gameend={})))
        for value in (False,True):
            decoded=self.codec.decode('ActionNoTile',self.codec.encode('ActionNoTile',dict(gameend=value)))
            self.assertEqual(m.has_game_end(decoded),value)

    def test_1204_preserves_receiving_without_premature_match_completion(self):
        async def run():
            c=self.client()
            async def call(method):raise SoulRPCError(method,1204)
            c.game=SimpleNamespace(call=call)
            await c.finish_round('ActionHule',{})
            self.assertIsNone(c.result)
            self.assertEqual(c.pending_round_error.code,1204)
            self.assertEqual(c.diagnostic['round_end'][-1]['confirm_error_code'],1204)
            self.assertIsNotNone(c.result_wait_deadline)
            self.assertFalse(any(e['type']=='end_game' for e in c.policy.events))
        asyncio.run(run())

    def test_other_confirm_errors_are_not_suppressed(self):
        async def run():
            c=self.client()
            async def call(method):raise SoulRPCError(method,151)
            c.game=SimpleNamespace(call=call)
            with self.assertRaises(SoulRPCError):await c.finish_round('ActionHule',{})
        asyncio.run(run())

    def test_terminal_notification_never_calls_confirm_next_round(self):
        async def run():
            c=self.client();calls=[]
            async def call(*args):calls.append(args)
            c.game=SimpleNamespace(call=call)
            for name in ('ActionHule','ActionLiuJu'):
                await c.finish_round(name,self.codec.decode(name,self.codec.encode(name,dict(gameend={}))))
            self.assertEqual(calls,[])
            self.assertIsNone(c.result)
        asyncio.run(run())

    def run_terminal_race(self,send_result):
        codec=self.codec
        def notification(name,data):
            raw=codec.encode(name,data);keys=(132,94,78,66,57,162,31,96,28)
            encoded=bytes(v^(((23^len(raw))+5*i+keys[i%9])&255) for i,v in enumerate(raw))
            return ('lq.ActionPrototype',dict(name=name,data=base64.b64encode(encoded).decode()))
        class FakeRPC:
            def __init__(self,codec):self.notifications=asyncio.Queue();self.timeline=[]
            async def open(self,url):pass
            def notification_time(self,data):return None
            async def close(self):pass
            async def call(self,name,data=None):
                if name.endswith('requestConnection'):return dict(result=1)
                if name.endswith('.login'):return dict(account_id=10)
                if name.endswith('.joinRoom'):return dict(room=dict(max_player_count=4,mode=dict(mode=2,detail_rule=dict(dora_count=3))))
                if name.endswith('.readyPlay'):
                    await self.notifications.put(('lq.NotifyRoomGameStart',dict(connect_token='synthetic-token',game_uuid='synthetic-game')))
                if name.endswith('.authGame'):return dict(seat_list=[9,10,11,12])
                if name.endswith('.enterGame'):
                    data={k:copy.deepcopy(v) for k,v in CASES[0].items() if k not in ('expected','old_actual')}
                    data.update(ju=0,tiles=data['tiles'][:13])
                    await self.notifications.put(notification('ActionNewRound',data))
                    await self.notifications.put(notification('ActionHule',dict(
                        scores=[-2100,38200,52400,11500],delta_scores=[-5800,0,5800,0],
                        hules=[dict(seat=2,zimo=False)])))
                    if send_result:await self.notifications.put(('lq.NotifyGameEndResult',{}))
                if name.endswith('.confirmNewRound'):raise SoulRPCError(name,1204)
                return {}
        real_wait=asyncio.wait_for
        async def wait(awaitable,timeout):
            if not send_result and timeout<31:
                awaitable.close()
                raise asyncio.TimeoutError
            return await real_wait(awaitable,timeout)
        async def run(folder):
            c=m.SoulRoomClient('synthetic-account','synthetic-password','balanced',CP,12345,output=folder)
            original_action=c.action
            async def action(name,data,**kwargs):
                if name=='ActionHule':c.last_discard=(0,'1m')
                return await original_action(name,data,**kwargs)
            c.action=action
            if send_result:
                result=await c.run()
                self.assertEqual(result['scores'],[-2100,38200,52400,11500])
                self.assertEqual(c.diagnostic['stage'],'completed')
                self.assertEqual(sum(e['type']=='end_game' for e in c.policy.events),1)
            else:
                with self.assertRaises(SoulRPCError) as error:await c.run()
                self.assertEqual(error.exception.code,1204)
                self.assertIsNone(c.result)
                self.assertFalse(any(e['type']=='end_game' for e in c.policy.events))
            return c
        version=dict(resource='0.16.289',package='4.0.51',client_version_string='WebGL_2022-0.16.289')
        with tempfile.TemporaryDirectory() as folder,patch.object(m,'RPC',FakeRPC),\
             patch.object(m,'gateway',return_value=(version,'wss://route-2.maj-soul.com')),\
             patch.object(m.asyncio,'wait_for',side_effect=wait):
            return asyncio.run(run(folder))

    def test_1204_then_authoritative_result_completes_without_disconnect(self):
        self.run_terminal_race(True)

    def test_1204_without_result_is_bounded_and_does_not_fabricate_completion(self):
        self.run_terminal_race(False)


class RPCChecks(unittest.TestCase):
    def test_socket_receipt_time_survives_notification_queue(self):
        async def run():
            codec=Codec(live=True);rpc=RPC(codec)
            class WS:
                close_code=1000
                def __aiter__(self):return self
                async def __anext__(self):
                    if getattr(self,'sent',False):raise StopAsyncIteration
                    self.sent=True
                    wrapper=codec.cls('Wrapper')(name='.lq.NotifyGameEndResult',data=codec.encode('NotifyGameEndResult',{}))
                    return b'\x01'+wrapper.SerializeToString()
            rpc.ws=WS()
            await rpc.read()
            name,data=await rpc.notifications.get()
            self.assertEqual(name,'lq.NotifyGameEndResult')
            self.assertIsNotNone(rpc.notification_time(data))
            self.assertIsNone(rpc.notification_time(data))
        asyncio.run(run())

    def test_rpc_timeline_excludes_payloads(self):
        async def run():
            codec=Codec(live=True);rpc=RPC(codec)
            class WS:
                async def send(self,raw):
                    _,future=next(iter(rpc.pending.values()))
                    future.set_result({})
            rpc.ws=WS()
            await rpc.call('.lq.FastTest.inputOperation',dict(type=1,tile='1m'))
            trace=list(rpc.timeline)
            self.assertEqual(trace[0]['status'],'acknowledged')
            self.assertNotIn('tile',json.dumps(trace))
            self.assertIn('elapsed_seconds',trace[0])
        asyncio.run(run())


if __name__=='__main__':unittest.main(verbosity=2)
