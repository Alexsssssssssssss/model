"""Bounded reconnect and authoritative own-game replay, without input retries.

Restore actions are plain protobuf, unlike XOR live ActionPrototype packets.
Historical operations are never submitted. Only the latest synchronized
server operation can cause a new decision.
"""
import asyncio
import base64
import copy
import hashlib
import json
import time

from websockets.exceptions import ConnectionClosed
from majsoul_protocol import RPC
from mahjong_stats import analyze

NETWORK_ERRORS=(OSError,asyncio.TimeoutError,ConnectionClosed)
RECONNECT_SECONDS=120.
RECONNECT_DELAYS=(1.,2.,4.,8.,15.,15.)


class RecoveryNeeded(ConnectionError):
    """A connection or action-stream gap needs authoritative reconstruction."""


def round_key(data):
    return (data.get('chang',0),data.get('ju',0),data.get('ben',0))


def event_round_key(event):
    return ('ESWN'.index(event['bakaze']),event['kyoku']-1,event['honba'])


def complete_events(events):
    """Exclude unfinished round statistics; never manufacture a round result."""
    result=[];hand=None;excluded=0
    for event in events:
        if event['type']=='start_kyoku':
            if hand is not None:excluded+=1
            hand=[event]
        elif hand is not None:
            hand.append(event)
            if event['type']=='end_kyoku':result.extend(hand);hand=None
        elif event['type'] in ('start_game','end_game'):result.append(event)
    if hand is not None:excluded+=1
    return result,excluded


class SoulRecoveryMixin:
    def decode_action_packet(self,packet,*,restored=False):
        raw=base64.b64decode(packet['data'],validate=True)
        if not restored:
            keys=(132,94,78,66,57,162,31,96,28)
            raw=bytes(v^(((23^len(raw))+5*i+keys[i%9])&255) for i,v in enumerate(raw))
        name=packet['name']
        return name,self.codec.decode(name,raw),hashlib.sha256(name.encode()+raw).hexdigest()

    async def process_prototype(self,packet,*,received_at=None,restored=False,replaying=False):
        name,data,digest=self.decode_action_packet(packet,restored=restored)
        step=int(packet.get('step',0))
        hashes=getattr(self,'_step_hashes',{})
        key=round_key(data) if name=='ActionNewRound' else getattr(self,'_live_round_key',None)
        current=getattr(self,'_live_round_key',None)
        if name=='ActionNewRound' and current is not None and key<current:
            self.diagnostic['old_round_notifications_ignored']=self.diagnostic.get('old_round_notifications_ignored',0)+1
            return None
        if name=='ActionMJStart' and current is not None:return None
        new_round=name=='ActionNewRound' and key!=getattr(self,'_live_round_key',None)
        if getattr(self,'_awaiting_fresh_round',False) and name not in ('ActionNewRound','ActionMJStart'):
            raise RecoveryNeeded('恢复连接后尚未取得当前局的完整记录')
        if new_round:
            hashes={};self._last_step=None;self._live_round_key=key;self._awaiting_fresh_round=False
        last=getattr(self,'_last_step',None)
        if step in hashes:
            if hashes[step]!=digest:raise RecoveryNeeded('雀魂同一步骤的数据不一致，需要同步')
            self.diagnostic['duplicate_notifications_ignored']=self.diagnostic.get('duplicate_notifications_ignored',0)+1
            return None
        if last is not None and not new_round and step!=last+1:
            raise RecoveryNeeded('雀魂对局步骤不连续，需要同步')
        hashes[step]=digest;self._step_hashes=hashes;self._last_step=step
        await self.action(name,data,received_at=received_at,replaying=replaying)
        return name,data

    async def restore_game(self,reply,*,complete_sync=True):
        actions=(reply.get('game_restore') or {}).get('actions') or []
        if not actions:
            if reply.get('is_end'):
                self.result_wait_deadline=time.monotonic()+30
                return None
            raise RecoveryNeeded('服务器未返回可重建的完整对局动作，暂不出牌')
        decoded=[self.decode_action_packet(p,restored=True) for p in actions]
        first=next((i for i,(name,_,_) in enumerate(decoded) if name=='ActionNewRound'),None)
        if first is None or any(n!='ActionMJStart' for n,_,_ in decoded[:first]):
            raise RecoveryNeeded('恢复记录缺少完整配牌，暂不出牌')
        # Validate the entire sequence before changing any policy state.
        for a,b in zip(actions,actions[1:]):
            if int(b.get('step',0))!=int(a.get('step',0))+1:
                raise RecoveryNeeded('恢复记录步骤不完整，暂不出牌')
        old=self.policy;events=old.events;key=round_key(decoded[first][1])
        starts=[i for i,e in enumerate(events) if e['type']=='start_kyoku']
        prefix=list(events)
        if starts:
            index=starts[-1];tail=events[index:]
            if event_round_key(events[index])==key:
                prefix=events[:index]
            else:
                # We cannot prove that no entire intermediate round was lost.
                self.diagnostic['recovery_crossed_round']=True
                if not any(e['type']=='end_kyoku' for e in tail):
                    self.diagnostic.setdefault('recovery_partial_rounds',[]).append(copy.deepcopy(tail))
                    prefix=events[:index]
        fresh=type(old)(self.checkpoint,old.seat)
        for event in prefix:fresh.event(copy.deepcopy(event))
        fresh.decision_count=old.decision_count
        self.policy=fresh;self.first_discard_record=None
        self._last_step=None;self._step_hashes={};self._live_round_key=None
        self._awaiting_fresh_round=False
        latest=None
        for packet in actions:
            value=await self.process_prototype(packet,restored=True,replaying=True)
            if value is not None:latest=value
        # Catch native encoding/state errors before advertising recovery.
        if getattr(fresh,'native',None):fresh.native.flush(fresh.events)
        self.diagnostic['last_restore']=dict(actions=len(actions),step=self._last_step,
            historical_inputs_sent=0,round=list(key))
        if complete_sync:await self.game.call('.lq.FastTest.finishSyncGame')
        if not reply.get('is_end'):await self.game.call('.lq.FastTest.clearLeaving')
        # Notifications may have advanced the game while sync was in flight.
        # Apply them without choosing from any superseded operation window.
        deferred=[]
        while not self.game.notifications.empty():
            name,data=self.game.notifications.get_nowait()
            received=self.game.notification_time(data)
            if name=='lq.ActionPrototype':
                value=await self.process_prototype(data,received_at=received,replaying=True)
                if value is not None:latest=value
            elif name=='connection_closed':
                if not any(n=='lq.NotifyGameEndResult' for n,_ in deferred):raise RecoveryNeeded('同步期间连接再次中断')
            elif name in ('lq.NotifyGameTerminate','lq.NotifyAnotherLogin'):raise RuntimeError('雀魂服务器终止对局或账号已在其他设备登录')
            else:deferred.append((name,data))
        for value in deferred:await self.game.notifications.put(value)
        ended=bool(reply.get('is_end')) or any(n=='lq.NotifyGameEndResult' for n,_ in deferred)
        if ended:
            self.result_wait_deadline=time.monotonic()+30
        elif latest:
            name,data=latest
            if name in ('ActionHule','ActionNoTile','ActionLiuJu'):
                await self.finish_round(name,data)
            elif name!='ActionMJStart':
                # Re-evaluate only the final server-authorized operation.
                await self.act_on_operation(name,data)
        return latest

    async def open_game_session(self,*,recovering):
        old=getattr(self,'game',None)
        if old:
            history=self.diagnostic.setdefault('previous_game_rpc_timing',[])
            history.extend(list(getattr(old,'timeline',[])))
            self.diagnostic['previous_game_rpc_timing']=history[-256:]
            await old.close()
        factory=getattr(self,'_rpc_factory',RPC)
        self.game=factory(self.codec)
        await self.connect_route(self.game,self._game_url)
        auth=await self.game.call('.lq.FastTest.authGame',self._game_auth)
        seat=auth['seat_list'].index(self._game_auth['account_id'])
        if self.policy is None:
            self.policy=self._policy_factory(self.checkpoint,seat)
            self.emit(dict(type='start_game',id=seat,names=['player']*4,log=self._game_auth['game_uuid']))
        elif self.policy.seat!=seat:raise RuntimeError('重连后的账号座位发生变化，停止以免错误出牌')
        reply=await self.game.call('.lq.FastTest.enterGame')
        if reply.get('game_restore'):
            self.status('restoring_game')
            await self.restore_game(reply)
        elif reply.get('is_end'):
            self.result_wait_deadline=time.monotonic()+30
        elif recovering:
            # Empty restore can be an inter-round transition. Only a fresh
            # complete NewRound permits decisions; never use the old hand.
            self._awaiting_fresh_round=True;self._last_step=None;self._step_hashes={};self._live_round_key=None
            await self.wait_for_complete_round()

    async def wait_for_complete_round(self):
        deadline=time.monotonic()+10
        while True:
            name,data=await asyncio.wait_for(self.game.notifications.get(),max(.01,deadline-time.monotonic()))
            self.game.notification_time(data)
            if name=='connection_closed':raise RecoveryNeeded('等待恢复配牌时连接中断')
            if name in ('lq.NotifyGameTerminate','lq.NotifyAnotherLogin'):
                raise RuntimeError('雀魂服务器终止对局或账号已在其他设备登录')
            if name=='lq.NotifyGameEndResult':
                await self.game.notifications.put((name,data))
                self.result_wait_deadline=time.monotonic()+30
                return
            if name=='lq.ActionPrototype':
                action,event,_=self.decode_action_packet(data)
                if action=='ActionMJStart':continue
                if action!='ActionNewRound':raise RecoveryNeeded('服务器未提供完整配牌，重新请求恢复')
                plain=dict(data,data=base64.b64encode(self.codec.encode(action,event)).decode())
                await self.restore_game(dict(game_restore=dict(actions=[plain])),complete_sync=False)
                return
            if time.monotonic()>=deadline:raise RecoveryNeeded('等待完整配牌超时')

    async def reconnect_game(self,cause):
        deadline=time.monotonic()+RECONNECT_SECONDS
        self.status('reconnecting')
        rows=self.diagnostic.setdefault('reconnections',[])
        for attempt,delay in enumerate(RECONNECT_DELAYS,1):
            row=dict(attempt=attempt,reason=type(cause).__name__,status='waiting',delay_seconds=delay)
            rows.append(row);del rows[:-64]
            remaining=deadline-time.monotonic()
            if remaining<=delay:break
            await asyncio.sleep(delay)
            try:
                row['status']='connecting'
                await asyncio.wait_for(self.open_game_session(recovering=True),deadline-time.monotonic())
            except NETWORK_ERRORS as exc:
                row.update(status='network_error',error_type=type(exc).__name__)
                cause=exc;continue
            row['status']='restored';self.status('playing')
            return
        self.status('connection_failed')
        raise RuntimeError('雀魂网络重连未能在120秒内恢复，已保存对局和诊断') from cause

    async def receive_game_notification(self,deadline):
        wait_deadline=min(deadline,getattr(self,'result_wait_deadline',None) or deadline)
        try:name,data=await asyncio.wait_for(self.game.notifications.get(),max(.1,wait_deadline-time.monotonic()))
        except asyncio.TimeoutError:
            if getattr(self,'pending_round_error',None):raise self.pending_round_error
            if getattr(self,'result_wait_deadline',None):raise RuntimeError('雀魂已通知终局，但30秒内未收到整场结果，保存对局并停止')
            raise RuntimeError('雀魂对局超过任务时限，保存对局并停止')
        received_at=self.game.notification_time(data)
        if name=='lq.ActionPrototype':await self.process_prototype(data,received_at=received_at)
        elif name=='lq.NotifyGameEndResult':self.result=self.build_match_result(data)
        elif name=='connection_closed':
            self.diagnostic['last_connection_failure']=dict(error_type=data.get('error_type'),close_code=data.get('close_code'))
            raise RecoveryNeeded('雀魂对局网络中断')
        elif name in ('lq.NotifyGameTerminate','lq.NotifyAnotherLogin'):raise RuntimeError('雀魂服务器终止对局或账号已在其他设备登录')

    def build_match_result(self,data):
        # part_point_1 is the actual final tile-game score, not the uma total
        # (same field used by the bundled public log converter).
        players=(data.get('result') or {}).get('players') or []
        if len(players)==4 and {p.get('seat',0) for p in players}==set(range(4)):
            scores=[0]*4
            for p in players:scores[p.get('seat',0)]=int(p['part_point_1'])
        else:scores=self.final_scores
        if scores is None:raise RuntimeError('缺少雀魂终局分数')
        order=sorted(range(4),key=lambda s:(-scores[s],s));ranks=[order.index(s)+1 for s in range(4)]
        filtered,unfinished=complete_events(self.policy.events)
        partial=unfinished+len(self.diagnostic.get('recovery_partial_rounds',[]))
        seat=self.policy.seat
        if any(e['type']=='start_kyoku' for e in filtered):stats=analyze(filtered,scores,ranks)[seat]
        else:stats=dict(half_games=1,rank_sum=ranks[seat],hands=0,**{'rank_'+str(ranks[seat]):1})
        initial=getattr(self,'match_initial_scores',None)
        if initial is not None:stats['net_points']=scores[seat]-initial[seat]
        stats['partial_hands_excluded']=partial
        self.emit(dict(type='end_game',scores=scores))
        return dict(scores=scores,ranks=ranks,own_seat=seat,own_stats=stats,
            checkpoint_sha256=self.policy.model.source_sha256,profile=self.profile,
            statistics_complete=partial==0 and not self.diagnostic.get('recovery_crossed_round',False))
