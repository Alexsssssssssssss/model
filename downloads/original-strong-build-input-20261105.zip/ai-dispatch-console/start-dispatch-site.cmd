@echo off
call "%~dp0start-original-ai.cmd" site
