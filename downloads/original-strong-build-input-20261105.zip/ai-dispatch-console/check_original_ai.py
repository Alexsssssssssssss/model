"""Offline installation check. No account, room login or online game is used."""
import json
import platform
from pathlib import Path
import sys

import torch

from original_strong_live import OriginalStrongSession, WEIGHT_SHA256, BACKEND


def main():
    torch.set_num_threads(1)
    root = Path(__file__).resolve().parent
    from majsoul_live import SoulPolicy
    policy = SoulPolicy(root / 'models/original-strong.json', 0)
    session = policy.native
    policy.event(dict(type='start_game', names=['player']*4, id=0))
    policy.event(dict(type='start_kyoku', bakaze='E', kyoku=1, honba=0, kyotaku=0,
        oya=0, scores=[25000]*4, dora_marker='N',
        tehais=[['C','2m','3m','4m','5m','6m','2p','3p','4p','5p','6p','2s','3s']]+[['?']*13]*3))
    policy.event(dict(type='tsumo', actor=0, pai='4s'))
    request = policy.choose(dict(seat=0, operation_list=[dict(type=1)]))
    assert request['type'] == 1
    report = dict(status='passed', backend=BACKEND, platform=platform.system(),
        python=platform.python_version(), torch=torch.__version__,
        checkpoint_sha256=WEIGHT_SHA256, original_weights_unchanged=True,
        all_parameters_frozen=all(not p.requires_grad for p in [*session.original.brain.parameters(), *session.original.dqn.parameters()]),
        actual_native_discard=request, credentials_used=False, online_login_tested=False)
    (root / 'original-ai-check.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=True))


if __name__ == '__main__':
    main()
