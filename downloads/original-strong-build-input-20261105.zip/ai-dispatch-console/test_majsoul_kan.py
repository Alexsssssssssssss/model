"""Kan wire regression: real protobuf, simulator and original native state.

No account or transport connection is used. Notification types are independent
of inputOperation types (ankan request 4, notification 3; kakan request 6,
notification 2).
"""
import asyncio
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import torch
from riichienv import RiichiEnv, GameRule, GameType

import majsoul_live as soul
import original_strong_live as original
from majsoul_protocol import Codec
from tenhou_live import run_all

B = Path(__file__).resolve().parent
REST = ['1m','2m','3m','7m','8m','9m','1p','2p','3p','1s','2s','3s','E']


class KanChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)
        cls.codec = Codec(live=True)
        cls.base = original.OriginalStrongSession(B/'models/original-strong.json', 0)
        cls.shared = (cls.base.original, cls.base.Bot, cls.base.model)

    def client(self, own, actor, hand):
        p = soul.SoulPolicy.__new__(soul.SoulPolicy)
        p.seat = own
        p.native = original.OriginalStrongSession(None, own, self.shared)
        p.model = p.native.model
        p.env = RiichiEnv(game_mode=int(GameType.YON_HANCHAN), rule=GameRule.default_mjsoul())
        p.events, p.obs, p.pending_reach, p.decision_count = [], None, False, 0
        p.event(dict(type='start_game', names=['player']*4))
        hands = [['?']*13 for _ in range(4)]
        hands[own] = hand if own == actor else REST
        p.event(dict(type='start_kyoku', bakaze='E', kyoku=1, honba=0, kyotaku=0,
                     oya=actor, scores=[25000]*4, dora_marker='N', tehais=hands))
        c = soul.SoulRoomClient.__new__(soul.SoulRoomClient)
        c.policy, c.last_discard, c.doras = p, None, ['4z']
        c.first_discard_record, c.result = None, None
        c.final_scores = [25000]*4
        c.diagnostic = dict(decision_timing=[])
        c.calls = []
        async def call(*args):
            c.calls.append(args)
        c.game = SimpleNamespace(call=call)
        return c

    async def wire(self, c, kind, data):
        await c.action(kind, self.codec.decode(kind, self.codec.encode(kind, data)))

    def test_ankan_all_seats_observers_red_fives_and_rinshan(self):
        async def run(actor, own, tile):
            base = tile.rstrip('r')
            copies = [base]*3+[base+'r'] if base.startswith('5') else [base]*4
            c = self.client(own, actor, copies[:3]+REST[:10])
            p = c.policy
            await self.wire(c, 'ActionDealTile', dict(seat=actor, tile=soul.from_mjai(copies[-1]) if own==actor else ''))
            await self.wire(c, 'ActionAnGangAddGang', dict(seat=actor, type=3, tiles=soul.from_mjai(tile), doras=['4z','5z']))
            events = [e for e in p.events if e['type'] in ('ankan','kakan')]
            self.assertEqual(len(events), 1)
            self.assertEqual(events[0]['type'], 'ankan')
            self.assertEqual(sorted(events[0]['consumed']), sorted(copies))
            p.native.flush(p.events)  # Every observer's real native state accepts it.
            await self.wire(c, 'ActionDealTile', dict(seat=actor, tile='4s' if own==actor else ''))
            if own == actor:
                # The actor can really select and send a legal rinshan discard.
                request = p.choose(dict(seat=own, operation_list=[dict(type=1)]))
                self.assertEqual(request['type'], 1)
                await self.wire(c, 'ActionDiscardTile', dict(seat=actor, tile=request['tile'], moqie=request['moqie']))
            else:
                await self.wire(c, 'ActionDiscardTile', dict(seat=actor, tile='4s', moqie=True))
            p.native.flush(p.events)
            self.assertIsNone(c.result)
            self.assertFalse(any(e['type']=='end_game' for e in p.events))
        for actor in range(4):
            for own in range(4):
                for tile in ['C','5m','5pr','5s']:
                    with self.subTest(actor=actor, observer=own, tile=tile):
                        asyncio.run(run(actor, own, tile))

    def test_kakan_keeps_actual_pon_red_identity_and_rinshan(self):
        async def run(own, called, consumed, added):
            actor=1
            c=self.client(own, actor, consumed+REST[:11])
            p=c.policy
            # Public pon followed by the actor's discard and next draw.
            p.event(dict(type='tsumo',actor=0,pai=called if own==0 else '?'))
            p.event(dict(type='dahai',actor=0,pai=called,tsumogiri=True))
            await self.wire(c,'ActionChiPengGang',dict(seat=actor,type=1,
                tiles=[soul.from_mjai(t) for t in [called,*consumed]],froms=[0,actor,actor]))
            await self.wire(c,'ActionDiscardTile',dict(seat=actor,tile='2s',moqie=False))
            await self.wire(c,'ActionDealTile',dict(seat=actor,tile=soul.from_mjai(added) if own==actor else ''))
            await self.wire(c,'ActionAnGangAddGang',dict(seat=actor,type=2,tiles=soul.from_mjai(added)))
            event=next(e for e in reversed(p.events) if e['type']=='kakan')
            self.assertEqual(event['pai'],added)
            self.assertEqual(sorted(event['consumed']),sorted([called,*consumed]))
            self.assertEqual(c.last_discard,(actor,added))
            self.assertFalse(any(e['type']=='ankan' for e in p.events))
            p.native.flush(p.events)
            await self.wire(c,'ActionDealTile',dict(seat=actor,tile='4s' if own==actor else ''))
            if own==actor:
                self.assertEqual(p.choose(dict(seat=own,operation_list=[dict(type=1)]))['type'],1)
            p.native.flush(p.events)
        for own in range(4):
            for suit in 'mps':
                for called,consumed,added in [
                    ('5'+suit,['5'+suit]*2,'5'+suit+'r'),
                    ('5'+suit+'r',['5'+suit]*2,'5'+suit)]:
                    with self.subTest(observer=own,called=called,added=added):
                        asyncio.run(run(own,called,consumed,added))

    def test_unknown_kan_notification_fails_explicitly(self):
        c=self.client(0,1,REST)
        for kind in [0,1,4,6,99]:
            with self.subTest(kind=kind), self.assertRaisesRegex(RuntimeError,'未知的雀魂杠通知类型'):
                asyncio.run(self.wire(c,'ActionAnGangAddGang',dict(seat=1,type=kind,tiles='7z')))

    def test_three_invited_clients_survive_the_same_public_ankan(self):
        async def run():
            clients=[self.client(own,3,REST) for own in range(3)]
            for c in clients:
                c.policy.event(dict(type='tsumo',actor=3,pai='?'))
            await asyncio.gather(*(self.wire(c,'ActionAnGangAddGang',
                dict(seat=3,type=3,tiles='7z')) for c in clients))
            for c in clients:
                c.policy.native.flush(c.policy.events)
            await asyncio.gather(*(self.wire(c,'ActionDealTile',dict(seat=3,tile='')) for c in clients))
            for c in clients:
                c.policy.native.flush(c.policy.events)
                self.assertEqual(sum(e['type']=='ankan' for e in c.policy.events),1)
                self.assertIsNone(c.result)
        asyncio.run(run())

    def test_kakan_chankan_result_keeps_the_declarer_as_target(self):
        async def run():
            c=self.client(0,1,REST)
            p=c.policy
            # Player 0 has 67m and waits on 5m/8m with an East pair.
            hand=['1p','2p','3p','1s','2s','3s','7s','8s','9s','6m','7m','E','E']
            p.events=[];p.env=RiichiEnv(game_mode=int(GameType.YON_HANCHAN),rule=GameRule.default_mjsoul())
            p.event(dict(type='start_game',names=['player']*4))
            p.event(dict(type='start_kyoku',bakaze='E',kyoku=1,honba=0,kyotaku=0,oya=2,
                scores=[25000]*4,dora_marker='N',tehais=[hand]+[['?']*13 for _ in range(3)]))
            p.event(dict(type='tsumo',actor=2,pai='?'))
            p.event(dict(type='dahai',actor=2,pai='5m',tsumogiri=True))
            await self.wire(c,'ActionChiPengGang',dict(seat=1,type=1,tiles=['5m']*3,froms=[2,1,1]))
            await self.wire(c,'ActionDiscardTile',dict(seat=1,tile='9p',moqie=False))
            await self.wire(c,'ActionDealTile',dict(seat=1,tile=''))
            # This case checks wire routing and result attribution, not the
            # simulator's chankan action availability or network acceptance.
            with patch.object(p,'choose',return_value=dict(type=9)):
                await self.wire(c,'ActionAnGangAddGang',dict(seat=1,type=2,tiles='0m',
                    operation=dict(seat=0,operation_list=[dict(type=9)])))
            self.assertEqual(c.calls[-1][1],dict(type=9))
            await self.wire(c,'ActionHule',dict(scores=[33000,17000,25000,25000],
                delta_scores=[8000,-8000,0,0],hules=[dict(seat=0,zimo=False)],gameend={}))
            hora=next(e for e in reversed(p.events) if e['type']=='hora')
            self.assertEqual(hora['target'],1)
            p.native.flush(p.events)
            self.assertIsNone(c.result)
        asyncio.run(run())

    def test_missing_kakan_pon_cannot_reuse_previous_hand(self):
        c=self.client(0,1,REST)
        c.policy.events.insert(1,dict(type='pon',actor=1,pai='C',consumed=['C','C'],target=2))
        with self.assertRaisesRegex(RuntimeError,'找不到加杠前'):
            asyncio.run(self.wire(c,'ActionAnGangAddGang',dict(seat=1,type=2,tiles='7z')))

    def test_invited_peer_failure_does_not_cancel_healthy_clients(self):
        async def run():
            finished=[]
            async def failing():raise RuntimeError('synthetic failed peer')
            async def healthy(seat):
                await asyncio.sleep(.01)
                finished.append(seat)
            with self.assertRaisesRegex(RuntimeError,'synthetic failed peer'):
                await run_all([SimpleNamespace(run=failing),
                    SimpleNamespace(run=lambda:healthy(1)),SimpleNamespace(run=lambda:healthy(2))],independent=True)
            self.assertEqual(sorted(finished),[1,2])
        asyncio.run(run())


if __name__=='__main__':unittest.main(verbosity=2)
