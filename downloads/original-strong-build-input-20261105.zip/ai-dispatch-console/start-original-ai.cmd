@echo off
setlocal
set OMP_NUM_THREADS=1
set MKL_NUM_THREADS=1
cd /d "%~dp0"
rem Keep the install path short enough for PyTorch headers on Windows.
if not exist .venv-original\Scripts\python.exe (
  py -3.12 -m venv .venv-original
  if errorlevel 1 goto python_error
)
.venv-original\Scripts\python -c "import sys,struct; assert sys.version_info[:2]==(3,12) and struct.calcsize('P')==8" >nul 2>&1
if errorlevel 1 goto python_error
.venv-original\Scripts\python -c "import torch,numpy; assert numpy.__version__=='1.26.4' and torch.__version__.split('+')[0]=='2.5.1'" >nul 2>&1
if errorlevel 1 (
  .venv-original\Scripts\python -m pip install "numpy==1.26.4"
  if errorlevel 1 goto error
  .venv-original\Scripts\python -m pip install "torch==2.5.1" --index-url https://download.pytorch.org/whl/cpu
  if errorlevel 1 goto error
)
.venv-original\Scripts\python -c "import riichienv,websockets,google.protobuf,UnityPy" >nul 2>&1
if errorlevel 1 (
  .venv-original\Scripts\python -m pip install -r requirements-original-ai.txt
  if errorlevel 1 goto error
)
.venv-original\Scripts\python check_original_ai.py
if errorlevel 1 goto error
if /i "%~1"=="check" exit /b 0
if /i "%~1"=="console" (
  .venv-original\Scripts\python dispatch_server.py
) else (
  if not exist dispatch-site.local.json (
    .venv-original\Scripts\python public_dispatch_server.py --setup
    if errorlevel 1 goto error
  )
  .venv-original\Scripts\python public_dispatch_server.py
)
if errorlevel 1 goto error
exit /b 0
:python_error
echo Requires 64-bit Python 3.12. Existing Python 3.12 can be reused.
echo Download: https://www.python.org/downloads/windows/
goto error
:error
echo Startup failed. Keep this window and read the error above.
echo If pip reports long paths, extract the ZIP to C:\mahjong-ai first.
if defined ORIGINAL_AI_NONINTERACTIVE exit /b 1
pause
exit /b 1
