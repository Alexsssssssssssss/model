"""Frozen uploaded policy for real-room adapters; no weight conversion or RL.

Server permissions constrain native legal masks before inference. The native
public-event encoder is independent of the older v5 policy/feature format.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import threading
import time
from collections import OrderedDict
from types import SimpleNamespace

import numpy as np
import torch

B = Path(__file__).resolve().parent
BACKEND = 'original-strong-native46'
WEIGHT_SHA256 = '55e78deeca0a020a9b99578e936a27cafdacaa62072259e354571554a93322c9'
_BUNDLES = OrderedDict()
_BUNDLE_LOCK = threading.RLock()


def is_original_checkpoint(path):
    path = Path(path)
    if path.suffix != '.json' or not path.is_file():
        return False
    return json.loads(path.read_text(encoding='utf-8')).get('backend') == BACKEND


def checkpoint_info(path):
    path = Path(path).resolve()
    info = json.loads(path.read_text(encoding='utf-8'))
    if info.get('backend') != BACKEND or info.get('sha256') != WEIGHT_SHA256:
        raise ValueError('原版强 AI 配置或权重身份不匹配')
    weight = (path.parent / info['weights']).resolve()
    if not weight.is_relative_to(path.parent) or not weight.is_file():
        raise ValueError('原版强 AI 权重文件缺失，请完整解压下载包')
    return info, weight


def tile_label(tile):
    if tile in ('E', 'S', 'W', 'N', 'P', 'F', 'C'):
        return 27 + ('E', 'S', 'W', 'N', 'P', 'F', 'C').index(tile)
    if tile.endswith('r') or tile.startswith('0'):
        return 34 + 'mps'.index(tile[-2] if tile.endswith('r') else tile[-1])
    return 'mps'.index(tile[-1]) * 9 + int(tile[0]) - 1


def ordinary_label(tile):
    label = tile_label(tile)
    return (4, 13, 22)[label - 34] if label >= 34 else label


def action_label(msg):
    kind = msg['type']
    if kind == 'dahai':
        return tile_label(msg['pai'])
    if kind == 'chi':
        called = ordinary_label(msg['pai'])
        low = min([called, *map(ordinary_label, msg['consumed'])])
        return 38 + called - low
    return dict(reach=37, pon=41, daiminkan=42, ankan=42, kakan=42,
                hora=43, ryukyoku=44, none=45)[kind]


def _module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _load_uncached(path):
    torch.set_num_threads(1)
    _, weights = checkpoint_info(path)
    if hashlib.sha256(weights.read_bytes()).hexdigest() != WEIGHT_SHA256:
        raise ValueError('原版强 AI 权重校验失败，请重新下载；不会替换为其他模型')
    if os.name == 'nt':
        if sys.version_info[:2] != (3, 12):
            raise RuntimeError('本包 Windows 推理组件需要 64 位 Python 3.12，请用 start-original-ai.cmd 启动')
        native = B / 'vendor/original-strong/windows-cp312'
    else:
        native = B / 'vendor/mortal-runtime'
    sys.path.insert(0, str(native))
    try:
        from libriichi.mjai import Bot
        from libriichi.consts import obs_shape
    except ImportError as exc:
        raise RuntimeError('原版 AI 原生组件不可用，请运行 check-original-ai.cmd 检查完整安装') from exc
    if tuple(obs_shape(3)) != (934, 34):
        raise RuntimeError('原生特征版本不匹配')
    network = _module('_live_original_network', B / 'vendor/mortal-source/mortal/model.py')
    engine = _module('_live_original_engine', B / 'vendor/mortal-source/mortal/engine.py')
    saved = torch.load(weights, map_location='cpu', weights_only=True)
    cfg = saved['config']
    if cfg['control']['version'] != 3 or cfg['resnet'] != dict(conv_channels=256, num_blocks=54):
        raise ValueError('上传原模型的网络配置不匹配')
    brain = network.Brain(version=3, **cfg['resnet'])
    head = network.DQN(version=3)
    brain.load_state_dict(saved['mortal'], strict=True)
    head.load_state_dict(saved['current_dqn'], strict=True)
    brain.requires_grad_(False)
    head.requires_grad_(False)
    runtime = engine.MortalEngine(brain, head, False, 3, device=torch.device('cpu'),
        enable_amp=False, enable_quick_eval=False, enable_rule_based_agari_guard=True,
        name='uploaded-original-strong-ai')
    return runtime, Bot, SimpleNamespace(source_sha256=WEIGHT_SHA256,
        source_checkpoint=str(weights), encoding='native934x34-46', profile='original-strong')


def _bundle(path):
    _, weight = checkpoint_info(path)
    st = weight.stat()
    key = (str(weight), st.st_size, st.st_mtime_ns)
    with _BUNDLE_LOCK:
        if key not in _BUNDLES:
            start = time.perf_counter()
            _BUNDLES[key] = SimpleNamespace(shared=_load_uncached(path), warmed=False,
                load_seconds=time.perf_counter()-start, warmup_seconds=0.)
            while len(_BUNDLES) > 4:
                _BUNDLES.popitem(last=False)
        _BUNDLES.move_to_end(key)
        return _BUNDLES[key]


def _load(path):
    return _bundle(path).shared


def prepare_original_model(path):
    """Load once and warm kernels/native features before a player joins a room."""
    start = time.perf_counter()
    bundle = _bundle(path)
    with _BUNDLE_LOCK:
        already_warm = bundle.warmed
        if not already_warm:
            begin = time.perf_counter()
            engine, Bot, _ = bundle.shared
            runtime = PermissionRuntime(engine)
            runtime.allowed = set(range(37))
            bot = Bot(runtime, 0)
            bot.react(json.dumps(dict(type='start_game', names=['player']*4)), can_act=False)
            bot.react(json.dumps(dict(type='start_kyoku', bakaze='E', kyoku=1, honba=0, kyotaku=0,
                oya=0, scores=[25000]*4, dora_marker='N',
                tehais=[['C','2m','3m','4m','5m','6m','2p','3p','4p','5p','6p','2s','3s']]+[['?']*13]*3)), can_act=False)
            reply = bot.react(json.dumps(dict(type='tsumo', actor=0, pai='4s')))
            if reply is None or json.loads(reply)['type'] != 'dahai':
                raise RuntimeError('原版模型预热未完成；尚未提交入房或准备请求')
            # Conditional kan selection uses a two-row native inference batch.
            engine.react_batch([np.zeros((934,34), np.float32)]*2,
                               [np.ones(46, bool)]*2, None)
            bundle.warmup_seconds = time.perf_counter()-begin
            bundle.warmed = True
    return dict(status='ready', already_warm=already_warm,
        preparation_seconds=time.perf_counter()-start, initial_load_seconds=bundle.load_seconds,
        initial_warmup_seconds=bundle.warmup_seconds, torch_threads=torch.get_num_threads(),
        checkpoint_sha256=WEIGHT_SHA256, weights_updated=False)


class PermissionRuntime:
    engine_type = 'mortal'
    is_oracle = False
    version = 3
    enable_quick_eval = False  # Every native decision must intersect server permissions.
    enable_rule_based_agari_guard = True  # Preserve the original decoder behavior.
    name = 'uploaded-original-strong-ai'

    def __init__(self, original):
        self.original = original
        self.allowed = None
        self.kan_tiles = set()
        self.last = None

    def react_batch(self, obs, masks, invisible_obs):
        if invisible_obs is not None:
            raise ValueError('原版 AI 不接受对手暗牌')
        masks = np.stack(masks).astype(bool)
        if self.allowed is None or not 1 <= len(masks) <= 2 or masks.shape[1] != 46:
            raise RuntimeError('缺少平台动作许可或原生动作形状错误')
        original_masks = masks.copy()
        permit = np.zeros(46, dtype=bool)
        permit[list(self.allowed)] = True
        masks[-1] &= permit
        if not masks[-1].any():
            raise RuntimeError('原版 AI 与平台合法动作没有交集，请下载诊断记录')
        if len(masks) == 2 and 42 in self.allowed:
            kan = np.zeros(46, dtype=bool)
            kan[list(self.kan_tiles)] = True
            masks[0] &= kan
            if not masks[0].any():
                # Reject the unavailable kan before scoring; other legal
                # actions can still be selected by the unchanged policy.
                masks[-1, 42] = False
                masks[0] = original_masks[0]
        if not masks[-1].any():
            raise RuntimeError('平台杠牌选项与原生选牌没有交集')
        if torch.get_num_threads() != 1:
            torch.set_num_threads(1)
        started = time.perf_counter()
        result = self.original.react_batch(obs, list(masks), None)
        self.last = dict(native_legal_labels=np.flatnonzero(original_masks[-1]).tolist(),
                         allowed_native_labels=np.flatnonzero(masks[-1]).tolist(),
                         native_action=int(result[0][-1]),
                         inference_seconds=time.perf_counter()-started,
                         torch_threads=torch.get_num_threads())
        return result


def canonical_event(event, seat):
    event = dict(event)
    if event['type'] == 'start_game':
        event.pop('id', None)
        event.pop('seed', None)
        if len(event.get('names', [])) != 4:
            event['names'] = ['player'] * 4
    elif event['type'] == 'start_kyoku':
        event['tehais'] = [list(h) if p == seat else ['?'] * 13 for p, h in enumerate(event['tehais'])]
    elif event['type'] == 'tsumo' and event['actor'] != seat:
        event['pai'] = '?'
    return json.dumps(event, ensure_ascii=False, sort_keys=True)


class OriginalStrongSession:
    def __init__(self, checkpoint, seat, shared=None):
        self.original, self.Bot, self.model = _load(checkpoint) if shared is None else shared
        self.seat = seat
        self.runtime = PermissionRuntime(self.original)
        self.reset()
        self.last_decision = None

    def reset(self):
        self.bot = self.Bot(self.runtime, self.seat)
        self.fed = []

    def fork(self):
        return OriginalStrongSession(None, self.seat, (self.original, self.Bot, self.model))

    def flush(self, events):
        lines = [canonical_event(e, self.seat) for e in events]
        if self.fed != lines[:len(self.fed)]:
            self.reset()
        for line in lines[len(self.fed):]:
            self.bot.react(line, can_act=False)
            self.fed.append(line)

    def choose(self, events, allowed, obs):
        choices = [a for group in allowed.values() for a in group]
        messages = [(a, json.loads(a.to_mjai())) for a in choices]
        labels = {action_label(msg) for _, msg in messages}
        kan_tiles = {ordinary_label(msg.get('pai', msg.get('consumed', ['?'])[0]))
                     for _, msg in messages if msg['type'] in ('ankan', 'kakan')}
        lines = [canonical_event(e, self.seat) for e in events]
        if not lines:
            raise RuntimeError('原版 AI 没有收到对局事件')
        # A retry with fewer server permissions replays state instead of
        # injecting the same draw/reach event twice into a live native state.
        if len(self.fed) >= len(lines) or self.fed != lines[:len(self.fed)]:
            self.reset()
        self.runtime.allowed = labels
        self.runtime.kan_tiles = kan_tiles
        self.runtime.last = None
        reply = None
        try:
            for i in range(len(self.fed), len(lines)):
                response = self.bot.react(lines[i], can_act=i == len(lines)-1)
                self.fed.append(lines[i])
                if response is not None:
                    reply = json.loads(response)
        finally:
            self.runtime.allowed = None
        if reply is None:
            if len(choices) == 1:
                action = choices[0]
                reply = json.loads(action.to_mjai())
            else:
                raise RuntimeError('原版 AI 在需要决策时未响应；不猜测切牌')
        if reply.get('actor', self.seat) != self.seat:
            raise RuntimeError('原版 AI 返回了其他玩家的动作')
        # Match physical copies only after the unchanged native policy selected
        # its semantic action. Ordinary/red discard labels remain distinct.
        matches = []
        for action, msg in messages:
            if msg['type'] != reply['type']:
                continue
            if 'pai' in reply and msg.get('pai') != reply['pai']:
                continue
            if 'consumed' in reply and sorted(msg.get('consumed', [])) != sorted(reply['consumed']):
                continue
            matches.append(action)
        if not matches:
            raise RuntimeError('原版 AI 返回动作不在平台许可列表中；已保留诊断')
        if reply['type'] == 'dahai':
            want_draw = reply.get('tsumogiri', False)
            action = next((a for a in matches if (a.tile == obs.drawn_tile) == want_draw), matches[0])
        else:
            action = matches[0]
        self.last_decision = dict(checkpoint_sha256=WEIGHT_SHA256,
            selected_native_label=action_label(reply), selected_action=json.loads(action.to_mjai()),
            selection='argmax', backend=BACKEND, **(self.runtime.last or {}))
        return action


class OriginalStrongOnlinePolicy:
    """Tenhou-compatible event interface for the untouched native policy."""
    def __init__(self, checkpoint, training=False, temperature=.15):
        if training:
            raise ValueError('原版强 AI 只用于冻结对战，不支持在线改权重')
        from riichienv import RiichiEnv, GameRule, GameType
        self.native = OriginalStrongSession(checkpoint, 0)
        self.model = self.native.model
        self.env = RiichiEnv(game_mode=int(GameType.YON_HANCHAN), rule=GameRule.default_tenhou())
        self.events = []
        self.training = False
        self.temperature = temperature
        self.trajectory = []
        self.decisions = 0
        self.last_decision = None

    def react(self, event):
        from tenhou_live import signature
        if event.get('type') == 'start_game':
            event = dict(event)
            event.pop('id', None)
            if len(event.get('names', [])) != 4:
                event['names'] = ['player'] * 4
        if event.get('type') == 'start_kyoku' and event.get('oya') == 0 and len(event['tehais'][0]) == 14:
            initial = dict(event, tehais=[list(h) for h in event['tehais']])
            tile = initial['tehais'][0].pop()
            self.react(initial)
            return self.react(dict(type='tsumo', actor=0, pai=tile, possible_actions=[]))
        self.events.append(event)
        obs = self.env.observe_event(event, 0)
        if event['type'] == 'end_game':
            self.native.flush(self.events)
        if obs is None:
            return dict(type='none')
        signatures = {signature(a) for a in event.get('possible_actions', [])}
        forbidden = set(event.get('cannot_dahai', []))
        allowed = {}
        for action in obs.legal_actions():
            msg = json.loads(action.to_mjai())
            if msg['type'] == 'dahai':
                valid = msg['pai'] not in forbidden
            elif msg['type'] == 'none':
                valid = True
            elif event['type'] == 'reach' and msg['type'] == 'reach':
                valid = False
            else:
                valid = signature(msg) in signatures or msg['type'] in ('hora', 'reach', 'ryukyoku') and any(
                    a['type'] == msg['type'] for a in event.get('possible_actions', []))
            if valid:
                allowed.setdefault(action.encode(), []).append(action)
        if not allowed:
            raise RuntimeError('天凤许可与原版模型合法动作没有交集')
        action = self.native.choose(self.events, allowed, obs)
        msg = json.loads(action.to_mjai())
        if msg['type'] == 'dahai':
            msg['tsumogiri'] = action.tile == obs.drawn_tile
        self.decisions += 1
        self.last_decision = dict(self.native.last_decision, id=self.decisions,
            selected_action=msg, allowed_labels=sorted(allowed),
            native_legal=[json.loads(a.to_mjai()) for a in obs.legal_actions()])
        return msg
