"""Fault-injected own-game reconnect, using real protobuf and native policy.

No account login or live server is used. In particular an input whose ACK is
lost must never be blindly retransmitted after authoritative replay.
"""
import asyncio
import base64
import copy
import time
import tempfile
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock,patch

import majsoul_live as m
import majsoul_recovery as recovery
from majsoul_protocol import Codec,SoulRPCError
import original_strong_live as original

B=Path(__file__).resolve().parent
CP=B/'models/original-strong.json'
HAND=['7z','2m','3m','4m','5m','6m','2p','3p','4p','5p','6p','2s','3s']


class ReconnectChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        original.prepare_original_model(CP)
        cls.codec=Codec(live=True)

    def client(self,seat=0):
        c=m.SoulRoomClient('synthetic-account','synthetic-password','balanced',CP,12345,output=B)
        c.policy=m.SoulPolicy(CP,seat)
        c.policy.event(dict(type='start_game',names=['player']*4))
        c.game=SimpleNamespace(call=AsyncMock(return_value={}),close=AsyncMock(),
            notifications=asyncio.Queue(),notification_time=lambda data:None,timeline=[])
        return c

    def packet(self,step,name,data,*,live=False):
        raw=self.codec.encode(name,data)
        if live:
            keys=(132,94,78,66,57,162,31,96,28)
            raw=bytes(v^(((23^len(raw))+5*i+keys[i%9])&255) for i,v in enumerate(raw))
        return dict(step=step,name=name,data=base64.b64encode(raw).decode())

    def new_round(self,**extra):
        data=dict(chang=0,ju=0,ben=0,liqibang=0,scores=[25000]*4,doras=['4z'],tiles=HAND+['4s'])
        data.update(extra)
        return data

    def reply(self,actions,**extra):
        data=dict(step=actions[-1]['step'],game_restore=dict(actions=actions,passed_waiting_time=1))
        data.update(extra)
        return self.codec.decode('ResEnterGame',self.codec.encode('ResEnterGame',data))

    def confirmed_discard(self):
        return [self.packet(0,'ActionNewRound',self.new_round(operation=dict(seat=0,operation_list=[dict(type=1)]))),
                self.packet(1,'ActionDiscardTile',dict(seat=0,tile='7z',moqie=False)),
                self.packet(2,'ActionDealTile',dict(seat=1,tile=''))]

    def inputs(self,c):
        return [v for v in c.game.call.call_args_list if v.args[0] in
            ('.lq.FastTest.inputOperation','.lq.FastTest.inputChiPengGang')]

    def test_lost_ack_confirmed_discard_is_not_submitted_again(self):
        async def run():
            c=self.client();data=self.new_round(operation=dict(seat=0,operation_list=[dict(type=1)]))
            c.game.call.side_effect=ConnectionError('synthetic ACK loss after acceptance')
            with patch.object(m,'ROUND_OPENING_SECONDS',0.):
                with self.assertRaises(ConnectionError):await c.action('ActionNewRound',data)
            self.assertEqual(len(self.inputs(c)),1)
            old_native=c.policy.native
            c.game.call=AsyncMock(return_value={})
            await c.restore_game(self.reply(self.confirmed_discard()))
            self.assertEqual(self.inputs(c),[])
            self.assertIsNot(c.policy.native,old_native)
            self.assertEqual(sum(e['type']=='dahai' and e['actor']==0 for e in c.policy.events),1)
            self.assertEqual(sum(e['type']=='start_kyoku' for e in c.policy.events),1)
            self.assertEqual(c.diagnostic['last_restore']['historical_inputs_sent'],0)
        asyncio.run(run())

    def test_pending_opening_recomputes_once_and_preserves_dealt_tile_flag(self):
        async def run():
            c=self.client()
            packet=self.packet(0,'ActionNewRound',self.new_round(operation=dict(seat=0,operation_list=[dict(type=1)])))
            with patch.object(m,'ROUND_OPENING_SECONDS',0.):await c.restore_game(self.reply([packet]))
            inputs=self.inputs(c)
            self.assertEqual(len(inputs),1)
            self.assertEqual(inputs[0].args[1]['tile'],'7z')
            self.assertFalse(inputs[0].args[1]['moqie'])
            methods=[v.args[0] for v in c.game.call.call_args_list]
            self.assertLess(methods.index('.lq.FastTest.finishSyncGame'),methods.index('.lq.FastTest.inputOperation'))
        asyncio.run(run())

    def test_only_final_operation_is_submitted_after_many_historical_turns(self):
        async def run():
            c=self.client();actions=self.confirmed_discard()
            for actor,tile in [(1,'4z'),(2,'2z'),(3,'1z')]:
                if actor!=1:actions.append(self.packet(len(actions),'ActionDealTile',dict(seat=actor,tile='')))
                actions.append(self.packet(len(actions),'ActionDiscardTile',dict(seat=actor,tile=tile,moqie=True)))
            actions.append(self.packet(len(actions),'ActionDealTile',dict(seat=0,tile='9p',
                operation=dict(seat=0,operation_list=[dict(type=1)]))))
            await c.restore_game(self.reply(actions))
            self.assertEqual(len(self.inputs(c)),1)
            self.assertIn(self.inputs(c)[0].args[1]['tile'],HAND[1:]+['4s','9p'])
        asyncio.run(run())

    def test_restored_plain_protobuf_and_duplicate_live_packets_are_distinct(self):
        async def run():
            c=self.client();actions=self.confirmed_discard()
            await c.restore_game(self.reply(actions))
            before=len(c.policy.events)
            duplicate=self.packet(2,'ActionDealTile',dict(seat=1,tile=''),live=True)
            self.assertIsNone(await c.process_prototype(duplicate))
            self.assertEqual(len(c.policy.events),before)
            self.assertEqual(c.diagnostic['duplicate_notifications_ignored'],1)
            conflicting=self.packet(2,'ActionDealTile',dict(seat=2,tile=''),live=True)
            with self.assertRaises(recovery.RecoveryNeeded):await c.process_prototype(conflicting)
        asyncio.run(run())

    def test_missing_restore_steps_do_not_choose_from_partial_state(self):
        async def run():
            c=self.client();actions=self.confirmed_discard();actions[-1]['step']=10
            before=list(c.policy.events)
            with self.assertRaises(recovery.RecoveryNeeded):await c.restore_game(self.reply(actions))
            self.assertEqual(c.policy.events,before)
            self.assertEqual(self.inputs(c),[])
        asyncio.run(run())

    def test_snapshot_without_complete_actions_does_not_guess_hand(self):
        async def run():
            c=self.client()
            with self.assertRaises(recovery.RecoveryNeeded):
                await c.restore_game(dict(game_restore=dict(snapshot=dict(hands=['1m']))))
            self.assertEqual(self.inputs(c),[])
        asyncio.run(run())

    def test_server_advanced_while_syncing_uses_newest_notification(self):
        async def run():
            c=self.client();actions=[self.confirmed_discard()[0]]
            await c.game.notifications.put(('lq.ActionPrototype',self.packet(1,'ActionDiscardTile',
                dict(seat=0,tile='7z',moqie=False),live=True)))
            await c.game.notifications.put(('lq.ActionPrototype',self.packet(2,'ActionDealTile',
                dict(seat=1,tile=''),live=True)))
            await c.restore_game(self.reply(actions))
            self.assertEqual(self.inputs(c),[])
            self.assertEqual(c._last_step,2)
        asyncio.run(run())

    def test_ankan_with_red_five_and_rinshan_survives_replay(self):
        async def run():
            c=self.client()
            hand=['5s']*3+['1m','2m','3m','7m','8m','9m','1p','2p','3p','1s']+['0s']
            actions=[self.packet(0,'ActionNewRound',self.new_round(tiles=hand)),
                self.packet(1,'ActionAnGangAddGang',dict(seat=0,type=3,tiles='5s',doras=['4z','5z'])),
                self.packet(2,'ActionDealTile',dict(seat=0,tile='4p',operation=dict(seat=0,operation_list=[dict(type=1)])))]
            await c.restore_game(self.reply(actions))
            kan=next(e for e in c.policy.events if e['type']=='ankan')
            self.assertEqual(sorted(kan['consumed']),sorted(['5s']*3+['5sr']))
            self.assertEqual(len(self.inputs(c)),1)
        asyncio.run(run())

    def test_own_riichi_is_reconstructed_once_from_server(self):
        async def run():
            c=self.client()
            hand=['1m','2m','3m','1p','2p','3p','1s','2s','3s','7s','8s','9s','1z','2z']
            actions=[self.packet(0,'ActionNewRound',self.new_round(tiles=hand)),
                self.packet(1,'ActionDiscardTile',dict(seat=0,tile='2z',moqie=False,is_liqi=True)),
                self.packet(2,'ActionDealTile',dict(seat=1,tile='',liqi=dict(seat=0,score=24000,liqibang=1)))]
            await c.restore_game(self.reply(actions))
            self.assertEqual(sum(e['type']=='reach' for e in c.policy.events),1)
            self.assertEqual(sum(e['type']=='reach_accepted' for e in c.policy.events),1)
            self.assertEqual(c.final_scores[0],24000)
            self.assertEqual(self.inputs(c),[])
        asyncio.run(run())

    def test_round_advanced_offline_preserves_partial_log_and_marks_statistics(self):
        async def run():
            c=self.client()
            await c.action('ActionNewRound',self.new_round(),replaying=True)
            actions=[self.packet(0,'ActionNewRound',self.new_round(ju=1,tiles=HAND))]
            await c.restore_game(self.reply(actions))
            self.assertEqual(len(c.diagnostic['recovery_partial_rounds']),1)
            self.assertEqual(sum(e['type']=='start_kyoku' for e in c.policy.events),1)
            players=[dict(seat=i,part_point_1=v) for i,v in enumerate([28000,22000,25000,25000])]
            result=c.build_match_result(dict(result=dict(players=players)))
            self.assertFalse(result['statistics_complete'])
            self.assertEqual(result['own_stats']['hands'],0)
            self.assertEqual(result['own_stats']['partial_hands_excluded'],2)
            self.assertEqual(result['own_stats']['net_points'],3000)
        asyncio.run(run())

    def test_terminal_result_queued_during_restore_prevents_an_extra_input(self):
        async def run():
            c=self.client();actions=[self.confirmed_discard()[0]]
            players=[dict(seat=i,part_point_1=25000) for i in range(4)]
            await c.game.notifications.put(('lq.NotifyGameEndResult',dict(result=dict(players=players))))
            await c.restore_game(self.reply(actions))
            self.assertEqual(self.inputs(c),[])
            self.assertIsNone(c.result)
            await c.receive_game_notification(time.monotonic()+5)
            self.assertIsNotNone(c.result)
        asyncio.run(run())

    def test_retry_success_backoff_and_cancellation(self):
        async def run():
            c=self.client();c.open_game_session=AsyncMock(side_effect=[OSError(),OSError(),None])
            with patch.object(recovery.asyncio,'sleep',new_callable=AsyncMock) as sleep:
                await c.reconnect_game(OSError())
                self.assertEqual([v.args[0] for v in sleep.call_args_list],[1.,2.,4.])
            self.assertEqual(c.diagnostic['stage'],'playing')
            self.assertEqual(c.diagnostic['reconnections'][-1]['status'],'restored')
            c.open_game_session.reset_mock()
            with patch.object(recovery.asyncio,'sleep',side_effect=asyncio.CancelledError()):
                with self.assertRaises(asyncio.CancelledError):await c.reconnect_game(OSError())
            c.open_game_session.assert_not_called()
        asyncio.run(run())

    def test_unrecoverable_model_error_is_not_network_retried(self):
        async def run():
            c=self.client();c.open_game_session=AsyncMock(side_effect=RuntimeError('model state error'))
            with patch.object(recovery.asyncio,'sleep',new_callable=AsyncMock):
                with self.assertRaisesRegex(RuntimeError,'model state error'):await c.reconnect_game(OSError())
            self.assertEqual(c.open_game_session.call_count,1)
        asyncio.run(run())

    def test_network_retry_is_bounded(self):
        async def run():
            c=self.client();c.open_game_session=AsyncMock(side_effect=OSError('still offline'))
            with patch.object(recovery.asyncio,'sleep',new_callable=AsyncMock):
                with self.assertRaisesRegex(RuntimeError,'120秒'):await c.reconnect_game(OSError())
            self.assertEqual(c.open_game_session.call_count,len(recovery.RECONNECT_DELAYS))
            self.assertEqual(self.inputs(c),[])
        asyncio.run(run())

    def test_three_clients_recover_independently(self):
        async def run():
            clients=[self.client(i) for i in range(3)]
            clients[0].open_game_session=AsyncMock(side_effect=[OSError(),None])
            clients[1].open_game_session=AsyncMock(return_value=None)
            clients[2].open_game_session=AsyncMock(side_effect=[OSError(),OSError(),None])
            with patch.object(recovery,'RECONNECT_DELAYS',(0.,0.,0.)):
                await asyncio.gather(*(c.reconnect_game(OSError()) for c in clients))
            self.assertEqual([c.open_game_session.call_count for c in clients],[2,1,3])
            self.assertTrue(all(c.diagnostic['stage']=='playing' for c in clients))
            self.assertEqual(len({id(c.policy.native.bot) for c in clients}),3)
        asyncio.run(run())

    def test_empty_enter_reply_waits_for_complete_new_round(self):
        async def run():
            c=self.client()
            await c.game.notifications.put(('lq.ActionPrototype',self.packet(0,'ActionNewRound',
                self.new_round(ju=1,tiles=HAND),live=True)))
            c._awaiting_fresh_round=True
            await c.wait_for_complete_round()
            self.assertFalse(c._awaiting_fresh_round)
            self.assertEqual(c._live_round_key,(0,1,0))
            self.assertEqual(self.inputs(c),[])
            methods=[v.args[0] for v in c.game.call.call_args_list]
            self.assertNotIn('.lq.FastTest.finishSyncGame',methods)
        asyncio.run(run())

    def test_new_round_or_step_gap_cannot_apply_stale_state(self):
        async def run():
            c=self.client()
            await c.restore_game(self.reply(self.confirmed_discard()))
            count=len(c.policy.events)
            with self.assertRaises(recovery.RecoveryNeeded):
                await c.process_prototype(self.packet(10,'ActionDealTile',dict(seat=1,tile=''),live=True))
            self.assertEqual(len(c.policy.events),count)
            self.assertEqual(self.inputs(c),[])
        asyncio.run(run())

    def test_reconnect_rejects_an_account_seat_change(self):
        async def run():
            c=self.client()
            old=c.game
            class FakeRPC:
                def __init__(self,codec):self.timeline=[]
                async def open(self,url):pass
                async def call(self,name,data):
                    return dict(result=1) if name.endswith('requestConnection') else dict(seat_list=[11,10,12,13])
            c._rpc_factory=FakeRPC;c._game_auth=dict(account_id=10,token='PRIVATE',game_uuid='same')
            c._game_url='wss://route-2.maj-soul.com/game-gateway'
            with self.assertRaisesRegex(RuntimeError,'座位发生变化'):await c.open_game_session(recovering=True)
            old.close.assert_awaited_once()
            self.assertNotIn('PRIVATE',str(c.diagnostic))
        asyncio.run(run())

    def test_full_worker_lost_ack_reconnects_and_finishes_same_game(self):
        # The fake gateway accepts one input, loses its ACK, returns the
        # authoritative replay on a new socket, then supplies a match result.
        # This exercises the actual run() exception/reconnect/result path.
        async def run(folder):
            instances=[];server_inputs=[];auth_payloads=[]
            outer=self
            class FakeRPC:
                def __init__(self,codec):
                    self.notifications=asyncio.Queue();self.timeline=[];self.closed=False
                    self.number=len(instances);instances.append(self)
                async def open(self,url):pass
                def notification_time(self,data):return None
                async def close(self):self.closed=True
                async def call(self,name,data=None):
                    if name.endswith('requestConnection'):return dict(result=1)
                    if name.endswith('.login'):return dict(account_id=10)
                    if name.endswith('.joinRoom'):return dict(room=dict(max_player_count=4,mode=dict(mode=2,detail_rule=dict(dora_count=3))))
                    if name.endswith('.readyPlay'):
                        await self.notifications.put(('lq.NotifyRoomGameStart',dict(
                            connect_token='PRIVATE_SYNTHETIC_TOKEN',game_uuid='SAME_SYNTHETIC_GAME')))
                    if name.endswith('.authGame'):
                        auth_payloads.append(dict(data));return dict(seat_list=[10,11,12,13])
                    if name.endswith('.enterGame'):
                        if self.number==1:
                            data=outer.new_round(operation=dict(seat=0,operation_list=[dict(type=1)]))
                            await self.notifications.put(('lq.ActionPrototype',outer.packet(0,'ActionNewRound',data,live=True)))
                        else:
                            await self.notifications.put(('lq.ActionPrototype',outer.packet(3,'ActionHule',dict(
                                scores=[-2100,38200,52400,11500],delta_scores=[-5800,0,5800,0],
                                hules=[dict(seat=2,zimo=False)],gameend={}),live=True)))
                            players=[dict(seat=i,part_point_1=v) for i,v in enumerate([-2100,38200,52400,11500])]
                            await self.notifications.put(('lq.NotifyGameEndResult',dict(result=dict(players=players))))
                            return outer.reply(outer.confirmed_discard())
                    if name.endswith('.inputOperation'):
                        server_inputs.append(dict(data))
                        raise ConnectionError('ACK lost after server acceptance')
                    return {}
            version=dict(resource='0.16.289',package='4.0.51',client_version_string='WebGL_2022-0.16.289')
            c=m.SoulRoomClient('synthetic-account','synthetic-password','balanced',CP,12345,output=folder)
            with patch.object(m,'RPC',FakeRPC),patch.object(m,'gateway',return_value=(version,'wss://route-2.maj-soul.com')),\
                 patch.object(m,'ROUND_OPENING_SECONDS',0.),patch.object(recovery,'RECONNECT_DELAYS',(0.,)):
                result=await c.run()
            self.assertEqual(len(server_inputs),1)
            self.assertEqual(auth_payloads[0],auth_payloads[1])
            self.assertEqual(len(instances),3)
            self.assertTrue(all(rpc.closed for rpc in instances))
            self.assertEqual(result['scores'],[-2100,38200,52400,11500])
            self.assertEqual(c.diagnostic['stage'],'completed')
            self.assertEqual(c.diagnostic['reconnections'][-1]['status'],'restored')
            self.assertEqual(sum(e['type']=='start_kyoku' for e in c.policy.events),1)
            self.assertEqual(sum(e['type']=='end_game' for e in c.policy.events),1)
            self.assertNotIn('PRIVATE_SYNTHETIC_TOKEN',str(c.diagnostic))
            self.assertNotIn('synthetic-password',str(c.diagnostic))
        with tempfile.TemporaryDirectory() as folder:asyncio.run(run(folder))


if __name__=='__main__':unittest.main(verbosity=2)
