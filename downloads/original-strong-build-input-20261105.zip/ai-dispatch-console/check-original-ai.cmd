@echo off
cd /d "%~dp0"
if not exist .venv-original\Scripts\python.exe (
  echo Run start-original-ai.cmd once to install dependencies.
) else (
  .venv-original\Scripts\python check_original_ai.py
)
pause
