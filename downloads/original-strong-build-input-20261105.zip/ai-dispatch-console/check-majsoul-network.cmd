@echo off
cd /d "%~dp0"
if not exist ".venv-original\Scripts\python.exe" (
 echo Please start the AI console once to install dependencies first.
 pause
 exit /b 1
)
".venv-original\Scripts\python.exe" majsoul_network_check.py
echo Report saved to majsoul-network-check.json. No account or password used.
pause
