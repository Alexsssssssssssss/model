"""Public attack/defense context; no hidden-hand risk estimates or forced actions."""
import numpy as np
from feature_v2 import encode as encode_v2
from riichienv import calculate_shanten
ENCODING='riichienv-0.4.10-public-defense238x34-82-v3'
CHANNELS=238

def augment(features,masks):
 x=np.asarray(features);mask=np.asarray(masks)
 if x.ndim!=3 or x.shape[1:]!=(224,34) or mask.shape!=(len(x),82):raise ValueError('Expected canonical224 features and full legal mask')
 out=np.zeros((len(x),CHANNELS,34),dtype=np.float32);out[:,:224]=x
 # Full own-river membership for every opponent, not only declared riichi.
 out[:,224:227]=(x[:,75:78]>0)
 groups=x[:,118:178].reshape(-1,3,4,5,34)
 counts=groups[:,:,:,:4].sum(axis=(3,4))
 known_open=(counts==3) # 4-tile kan planes do not reveal opened/concealed status.
 for p in range(3):
  out[:,227+p,:]=known_open[:,p].sum(axis=1)[:,None]/4
  held=groups[:,p,:,:4,:].sum(axis=(1,2));red=groups[:,p,:,4,:].sum(axis=1)
  out[:,230+p,:]=(held*x[:,215]+red).sum(axis=1)[:,None]/12
  kinds=(groups[:,p,:,:3,:].sum(axis=2)>0)&known_open[:,p,:,None]
  numbered=kinds[:,:,:27].any(axis=1).reshape(-1,3,9).any(axis=2)
  for row in np.flatnonzero((known_open[:,p].sum(axis=1)>=2)&(numbered.sum(axis=1)==1)):
   suit=int(np.flatnonzero(numbered[row])[0]);out[row,233+p,suit*9:suit*9+9]=1
 # Per-discard resulting shanten, not a hard minimum-shanten decision rule.
 for row in range(len(x)):
  counts=(x[row,:4]>0).sum(axis=0);hand=[k*4+i for k,c in enumerate(counts) for i in range(int(c))]
  for label in np.flatnonzero(mask[row,:37]):
   kind=int(label) if label<34 else (4,13,22)[int(label)-34]
   matching=next((t for t in hand if t//4==kind),None)
   if matching is None:raise ValueError('Legal discard missing from own observable hand')
   rest=hand.copy();rest.remove(matching);out[row,236,kind]=calculate_shanten(rest)/8;out[row,237,kind]=1
 assert np.isfinite(out).all()
 return out

def encode(obs):
 x=encode_v2(obs);mask=np.zeros(82,dtype=np.bool_)
 for a in obs.legal_actions():mask[a.encode()]=True
 return augment(x[None],mask[None])[0]
