"""Portable full-action PPO update; no platform transport or account access."""
import numpy as np
import torch

def initialize_value(value, checkpoint, profile, placement_utility, rule):
    """Transfer a critic only when its targets and game rules are compatible.

    Policy-only supervised parents legitimately have no critic. A new run
    resets its optimizer deliberately; same-run --resume restores it later.
    """
    if 'value' not in checkpoint:
        if 'selfplay' in checkpoint:
            raise ValueError('RL parent is missing its value branch')
        torch.nn.init.zeros_(value.weight);torch.nn.init.zeros_(value.bias)
        return 'zero_initialized_supervised_parent'
    old=checkpoint.get('selfplay',{})
    if (old.get('profile')!=profile or old.get('placement_utility')!=list(placement_utility)
            or old.get('rule')!=rule):
        raise ValueError('Parent critic reward or rule differs; explicit critic recalibration required')
    value.load_state_dict(checkpoint['value'],strict=True)
    if not all(torch.isfinite(p).all() for p in value.parameters()):
        raise ValueError('Non-finite parent critic')
    return 'inherited_parent_value'

def forward(model,value,x,mask,detach_value_features=False):
    h=model.encoder(x);logits=model.head(h).masked_fill(~mask,-1e9)
    return logits,value((h.detach() if detach_value_features else h).flatten(1)).squeeze(1)

def calibrate_value(model,value,optimizer,rows,returns,rng):
    """Fit terminal rank values without changing any policy parameter."""
    target=np.asarray(returns,dtype=np.float32)
    losses=[];before={k:p.detach().clone() for k,p in model.state_dict().items()}
    original_rates=[g['lr'] for g in optimizer.param_groups]
    try:
        for group in optimizer.param_groups:group['lr']=1e-3
        for _ in range(3):
            order=rng.permutation(len(rows))
            for start in range(0,len(rows),128):
                indices=order[start:start+128]
                x=torch.from_numpy(np.stack([rows[i][0] for i in indices]).astype(np.float32))
                with torch.no_grad():h=model.encoder(x).flatten(1)
                prediction=value(h).squeeze(1);loss=torch.nn.functional.mse_loss(prediction,torch.from_numpy(target[indices]))
                optimizer.zero_grad(set_to_none=True);loss.backward()
                norm=torch.nn.utils.clip_grad_norm_(value.parameters(),5.)
                if not torch.isfinite(norm):raise RuntimeError('Non-finite critic calibration gradient')
                optimizer.step();losses.append(loss.item())
    finally:
        for group,rate in zip(optimizer.param_groups,original_rates):group['lr']=rate
    if not all(torch.equal(p,before[k]) for k,p in model.state_dict().items()):
        raise RuntimeError('Critic calibration changed actor weights')
    return dict(stage='value_calibration',loss=float(np.mean(losses)),optimizer_steps=len(losses),
                actor_unchanged=True,decision_count=len(rows),anchor_kl=0.)


def optimize(model,value,anchor,optimizer,rows,returns,rng,temperature=1.0,detach_value_features=False,anchor_coefficient=.1):
    if not 0<temperature<=1:raise ValueError('PPO temperature must be in (0, 1]')
    if anchor_coefficient<0:raise ValueError('Anchor coefficient cannot be negative')
    x=np.stack([r[0] for r in rows]);mask=np.stack([r[1] for r in rows]);labels=np.array([r[2] for r in rows]);oldlp=np.array([r[3] for r in rows]);oldv=np.array([r[4] for r in rows]);target=np.array(returns,dtype=np.float32)
    advantage=target-oldv;advantage=(advantage-advantage.mean())/(advantage.std()+1e-6)
    if not mask[np.arange(len(labels)),labels].all():raise ValueError('Executed PPO action is outside its stored mask')
    # On-policy verification happens before any update, using exactly the
    # recorded legal mask and sampling temperature, including red fives.
    errors=[]
    with torch.no_grad():
        for start in range(0,len(rows),128):
            stop=min(start+128,len(rows));tx=torch.from_numpy(x[start:stop].astype(np.float32));tm=torch.from_numpy(mask[start:stop])
            lp=torch.distributions.Categorical(logits=model(tx,tm)/temperature).log_prob(torch.from_numpy(labels[start:stop]))
            errors.append(float(np.max(np.abs(lp.numpy()-oldlp[start:stop]))))
    old_logprob_error=max(errors)
    if old_logprob_error>2e-4:raise ValueError('Rollout log probability differs from current frozen policy')
    losses=[];kl=[];policy_losses=[];value_losses=[];entropies=[];policy_kls=[];updates=0;stop=False
    model.train();value.train()
    for _ in range(3):
        order=rng.permutation(len(rows))
        for start in range(0,len(rows),128):
            ix=order[start:start+128];tx=torch.from_numpy(x[ix].astype(np.float32));tm=torch.from_numpy(mask[ix]);ty=torch.from_numpy(labels[ix]);ta=torch.from_numpy(advantage[ix].astype(np.float32));tr=torch.from_numpy(target[ix]);tlp=torch.from_numpy(oldlp[ix].astype(np.float32))
            logits,v=forward(model,value,tx,tm,detach_value_features=detach_value_features);logits=logits/temperature;dist=torch.distributions.Categorical(logits=logits);lp=dist.log_prob(ty);ratio=(lp-tlp).exp()
            policy_loss=-torch.minimum(ratio*ta,ratio.clamp(.8,1.2)*ta).mean()
            imitation_kl=logits.new_zeros(())
            if anchor_coefficient:
                with torch.no_grad():ref=anchor(tx,tm)/temperature;ref_log=torch.log_softmax(ref,1);ref_prob=ref_log.exp()
                imitation_kl=(ref_prob*(ref_log-torch.log_softmax(logits,1))).sum(1).mean()
            value_loss=torch.nn.functional.mse_loss(v,tr);entropy=dist.entropy().mean()
            loss=policy_loss+.5*value_loss-.005*entropy+anchor_coefficient*imitation_kl
            assert torch.isfinite(loss)
            optimizer.zero_grad(set_to_none=True);loss.backward();torch.nn.utils.clip_grad_norm_([*model.parameters(),*value.parameters()],.5);optimizer.step()
            losses.append(loss.item());kl.append(imitation_kl.item());updates+=1
            approx_kl=((ratio-1)-(lp-tlp)).mean().item()
            policy_losses.append(policy_loss.item());value_losses.append(value_loss.item())
            entropies.append(entropy.item());policy_kls.append(approx_kl)
            if approx_kl>.04:stop=True;break
        if stop:break
    assert all(torch.isfinite(p).all() for p in [*model.parameters(),*value.parameters()])
    target_variance=float(np.var(target))
    return dict(loss=float(np.mean(losses)),anchor_kl=float(np.mean(kl)),anchor_coefficient=anchor_coefficient,old_logprob_error_before_update=old_logprob_error,optimizer_steps=updates,kl_early_stop=stop,temperature=temperature,
        policy_loss=float(np.mean(policy_losses)),value_loss=float(np.mean(value_losses)),
        entropy=float(np.mean(entropies)),policy_kl_max=float(max(policy_kls)),
        value_explained_variance_before_update=float(1-np.var(target-oldv)/target_variance) if target_variance>1e-12 else None,
        value_mse_before_update=float(np.mean((target-oldv)**2)),decision_count=len(rows))

