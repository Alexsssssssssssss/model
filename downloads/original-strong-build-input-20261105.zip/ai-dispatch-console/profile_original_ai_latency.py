"""Measure real worker-thread first requests with synthetic transport, no login."""
import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import sys
import time

import torch


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--project', type=Path, default=Path(__file__).resolve().parent)
    p.add_argument('--old', action='store_true')
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    root = a.project.resolve()
    sys.path.insert(0, str(root))
    import majsoul_live as m
    import original_strong_live as original
    torch.set_num_threads(1)  # Exactly the console's main-thread setup.
    async def benchmark():
        preparation = None
        if not a.old:
            preparation = await asyncio.to_thread(original.prepare_original_model, root/'models/original-strong.json')
        start = time.perf_counter()
        policy = m.SoulPolicy(root/'models/original-strong.json', 0)
        construction = time.perf_counter()-start
        policy.event(dict(type='start_game', names=['player']*4, id=0))
        client = m.SoulRoomClient('synthetic', 'synthetic', 'balanced', None, 12345, output=root)
        client.policy = policy
        requests = []
        class Game:
            async def call(self, method, request):
                requests.append(dict(method=method, request=request, at=time.perf_counter()))
                return {}
        client.game = Game()
        durations = []
        for i in range(3):
            begin = start if i == 0 else time.perf_counter()
            await client.action('ActionNewRound', dict(chang=0, ju=0, ben=i, liqibang=0,
                scores=[25000]*4, doras=['4z'],
                tiles=['7z','2m','3m','4m','5m','6m','2p','3p','4p','5p','6p','2s','3s','4s'],
                operation=dict(seat=0, operation_list=[dict(type=1)])))
            durations.append(requests[-1]['at']-begin)
        for item in requests:
            item.pop('at')
        return dict(adapter_version=m.ADAPTER_VERSION, old_package=a.old,
            model_preparation_before_game=preparation,
            construction_after_game_start_seconds=construction,
            request_seconds=durations, requests=requests,
            timings=client.diagnostic.get('decision_timing'),
            checkpoint_sha256=policy.model.source_sha256,
            credentials_used=False, real_platform_network_used=False)
    with ThreadPoolExecutor(max_workers=1) as pool:
        result = pool.submit(lambda: asyncio.run(benchmark())).result()
    a.output.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
