"""Offline regression suite for the uploaded, unmodified policy and adapters."""
import asyncio
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import torch
from riichienv import RiichiEnv, GameRule, GameType

import majsoul_live as soul
import original_strong_live as original
from tenhou_live import PrivateRoomClient

B = Path(__file__).resolve().parent
CHECKPOINT = B / 'models/original-strong.json'
HAND = ['1m','2m','3m','4m','5m','6m','1p','2p','3p','4s','5s','6s','E']


class OriginalChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)
        cls.base = original.OriginalStrongSession(CHECKPOINT, 0)
        cls.shared = (cls.base.original, cls.base.Bot, cls.base.model)

    def policy(self, hand=None, draw='S', seat=0):
        p = soul.SoulPolicy.__new__(soul.SoulPolicy)
        p.seat = seat
        p.native = original.OriginalStrongSession(None, seat, self.shared)
        p.model = p.native.model
        p.env = RiichiEnv(game_mode=int(GameType.YON_HANCHAN), rule=GameRule.default_mjsoul())
        p.events = []
        p.obs = None
        p.pending_reach = False
        p.decision_count = 0
        p.event(dict(type='start_game', id=seat, names=['player']*4))
        hands = [['?']*13 for _ in range(4)]
        hands[seat] = list(hand or HAND)
        p.event(dict(type='start_kyoku', bakaze='E', kyoku=1, honba=0, kyotaku=0,
                     oya=seat, scores=[25000]*4, dora_marker='N', tehais=hands))
        if draw is not None:p.event(dict(type='tsumo', actor=seat, pai=draw))
        return p

    def prefer(self, preferred, runtime=None):
        # Artificial logits exercise transport edge cases without changing a
        # single original weight. Actual inference is tested separately below.
        def react(obs, masks, invisible):
            masks = np.stack(masks)
            q = np.zeros(masks.shape, dtype=float)
            q[:, preferred] = 90.
            q[:, 37] = 100.
            q[~masks] = -np.inf
            return q.argmax(-1).tolist(), q.tolist(), masks.tolist(), [True]*len(masks)
        return patch.object(runtime or self.base.original, 'react_batch', side_effect=react)

    def test_dispatch_menu_preserves_original_digest_and_rejects_training(self):
        from dispatch_server import Console, models
        self.assertEqual(models()['original-strong']['weight_sha256'], original.WEIGHT_SHA256)
        with tempfile.TemporaryDirectory() as folder:
            c = Console(Path(folder))
            c.worker = lambda task: None
            for i in range(4):
                c.save_account(dict(platform='tenhou', label='TEST'+str(i), login=f'IDTEST{i}-TEST'))
            rows = [dict(account=a['key'], model='original-strong', learn=i==0) for i,a in enumerate(c.accounts)]
            with self.assertRaisesRegex(ValueError, '只支持冻结对战'):
                c.dispatch(dict(platform='tenhou', mode='rl', room=2456, games=8, bots=rows))
            result = c.dispatch(dict(platform='tenhou', mode='invite', room=2456, games=1, bots=rows[:1]))
            self.assertEqual(c.tasks[result['id']]['bots'][0]['checkpoint_sha256'], original.WEIGHT_SHA256)

    def test_native_tsumo_and_ron_map_to_correct_soul_requests(self):
        hand = ['1m','2m','3m','1p','2p','3p','1s','2s','3s','7s','7s','7s','E']
        with self.prefer(43):
            p = self.policy(hand, 'E')
            self.assertEqual(p.choose(dict(seat=0, operation_list=[dict(type=8)])), dict(type=8))
            p = self.policy(hand, None)
            p.event(dict(type='tsumo', actor=1, pai='?'))
            p.event(dict(type='dahai', actor=1, pai='E', tsumogiri=True))
            self.assertEqual(p.choose(dict(seat=0, operation_list=[dict(type=9)])), dict(type=9))

    def test_original_identity_frozen_and_not_trainable_online(self):
        self.assertEqual(self.base.model.source_sha256, original.WEIGHT_SHA256)
        self.assertTrue(all(not p.requires_grad for p in [*self.base.original.brain.parameters(), *self.base.original.dqn.parameters()]))
        with self.assertRaisesRegex(ValueError, '不支持在线'):
            original.OriginalStrongOnlinePolicy(CHECKPOINT, training=True)

    def test_red_five_riichi_exact_server_candidates_all_suits(self):
        for suit in 'mps':
            hand = ['1m','2m','3m','1p','2p','3p','1s','2s','3s','7s','8s','9s','5'+suit]
            for permitted in ['0'+suit, '5'+suit]:
                with self.subTest(suit=suit, permitted=permitted), self.prefer(original.tile_label('5'+suit+'r')):
                    p = self.policy(hand, '5'+suit+'r')
                    req = p.choose(dict(seat=0, operation_list=[dict(type=7, combination=[permitted])]))
                    self.assertEqual(req['type'], 7)
                    self.assertEqual(req['tile'], permitted)
                    self.assertEqual(req['moqie'], permitted.startswith('0'))
                    self.assertEqual(sum(e['type']=='reach' for e in p.events), 1)

    def test_missing_riichi_candidates_retry_without_double_state_event(self):
        for choices in [[], ['9p']]:
            with self.subTest(choices=choices), self.prefer(27):
                p = self.policy()
                before = copy.deepcopy(p.events)
                req = p.choose(dict(seat=0, operation_list=[dict(type=1), dict(type=7, combination=choices)]))
                self.assertEqual(req['type'], 1)
                self.assertEqual(p.events, before)
                self.assertFalse(p.pending_reach)

    def test_real_original_inference_obeys_a_riichi_subset(self):
        p = self.policy()
        req = p.choose(dict(seat=0, operation_list=[dict(type=7, combination=['2z'])]))
        self.assertEqual(req, dict(type=7, tile='2z', moqie=True))

    def test_dealer_first_discard_hand_and_draw_all_seats(self):
        async def run(seat, label, tile, moqie):
            p = self.policy(seat=seat)
            client = soul.SoulRoomClient('synthetic', 'synthetic', 'balanced', CHECKPOINT, 12345, output=B)
            client.policy = p
            calls = []
            class Game:
                async def call(self, *args):
                    calls.append(args)
            client.game = Game()
            async def fast_sleep(*_):
                pass
            with self.prefer(label), patch.object(soul.asyncio, 'sleep', fast_sleep):
                await client.action('ActionNewRound', dict(chang=0, ju=seat, ben=0, liqibang=0,
                    scores=[25000]*4, doras=['4z'],
                    tiles=['7z','2m','3m','4m','5m','6m','2p','3p','4p','5p','6p','2s','3s','4s'],
                    operation=dict(seat=seat, operation_list=[dict(type=1)])))
            self.assertEqual(calls[0][1], dict(type=1, tile=tile, moqie=moqie))
            self.assertGreater(len(p.last_decision['model_discard_tiles']), 1)
            self.assertEqual(client.diagnostic['dealer_first_discards'][-1]['status'], 'rpc_acknowledged')
        for seat in range(4):
            for label, tile, moqie in [(33, '7z', False), (21, '4s', True)]:
                with self.subTest(seat=seat, tile=tile):
                    asyncio.run(run(seat, label, tile, moqie))

    def test_tenhou_client_selects_native_backend_and_normalizes_14_tiles(self):
        client = PrivateRoomClient('IDTEST-TEST', 'balanced', CHECKPOINT, room=2456)
        self.assertIsInstance(client.policy, original.OriginalStrongOnlinePolicy)
        p = client.policy
        p.react(dict(type='start_game', id=0, names=[]))
        hand = ['C','2m','3m','4m','5m','6m','2p','3p','4p','5p','6p','2s','3s','4s']
        request = p.react(dict(type='start_kyoku', bakaze='E', kyoku=1, honba=0, kyotaku=0,
            oya=0, scores=[25000]*4, dora_marker='N', tehais=[hand]+[['?']*13]*3))
        self.assertEqual(request['type'], 'dahai')
        self.assertIn(request['pai'], hand)
        self.assertEqual(p.decisions, 1)
        # A completed hand must not prematurely finish a halfgame.
        p.react(dict(type='ryukyoku', deltas=[0]*4))
        p.react(dict(type='end_kyoku'))
        p.react(dict(type='end_game', scores=[25000]*4))

    def test_win_and_draw_wait_for_authoritative_match_end(self):
        async def run():
            p = self.policy()
            client = soul.SoulRoomClient('synthetic', 'synthetic', 'balanced', CHECKPOINT, 12345, output=B)
            client.policy = p
            client.final_scores = [25000]*4
            client.last_discard = (1, 'S')
            calls = []
            class Game:
                async def call(self, *args):
                    calls.append(args)
            client.game = Game()
            for name, data in [
                ('ActionHule', dict(scores=[25000]*4, delta_scores=[0]*4, hules=[dict(seat=0, zimo=True)])),
                ('ActionHule', dict(scores=[25000]*4, delta_scores=[0]*4, hules=[dict(seat=0, zimo=False), dict(seat=2, zimo=False)])),
                ('ActionNoTile', dict(scores=[dict(delta_scores=[0]*4)])),
                ('ActionLiuJu', {})]:
                before = len(calls)
                await client.action(name, data)
                self.assertEqual(len(calls), before+1)
                self.assertIsNone(client.result)
            before = len(calls)
            await client.action('ActionHule', dict(scores=[25000]*4, delta_scores=[0]*4,
                hules=[dict(seat=0, zimo=True)], gameend=True))
            self.assertEqual(len(calls), before)
            self.assertIsNone(client.result)
            self.assertFalse(any(e['type']=='end_game' for e in p.events))
        asyncio.run(run())

    def test_one_real_complete_halfgame_matches_unmodified_native_reference(self):
        from libriichi.mjai import Bot
        reference = type(self.base.original)(self.base.original.brain, self.base.original.dqn,
            False, 3, device=torch.device('cpu'), enable_amp=False, enable_quick_eval=True,
            enable_rule_based_agari_guard=True, name='unmodified-reference')
        class Player:
            def __init__(self, seat):
                self.seat = seat
                self.bot = Bot(reference, seat)
                self.events = []
            def choose(self, obs):
                reply = None
                for i, event in enumerate(obs.events):
                    event = json.loads(event) if isinstance(event, str) else event
                    self.events.append(event)
                    out = self.bot.react(original.canonical_event(event, self.seat), can_act=i==len(obs.events)-1)
                    if out:
                        reply = json.loads(out)
                if reply is None:
                    assert len(obs.legal_actions()) == 1
                    return obs.legal_actions()[0]
                action = obs.select_action_from_mjai(reply)
                assert action is not None
                return action
        env = RiichiEnv(seed=641900000, game_mode=int(GameType.YON_HANCHAN), rule=GameRule.default_tenhou())
        obs = env.reset()
        players = {p: Player(p) for p in range(4)}
        session = original.OriginalStrongSession(None, 0, self.shared)
        checked = 0
        while not env.done():
            actions = {}
            for seat, current in obs.items():
                action = players[seat].choose(current)
                if seat == 0:
                    allowed = {}
                    for a in current.legal_actions():
                        allowed.setdefault(a.encode(), []).append(a)
                    selected = session.choose(players[0].events, allowed, current)
                    self.assertEqual(json.loads(selected.to_mjai()), json.loads(action.to_mjai()))
                    checked += 1
                actions[seat] = action
            obs = env.step(actions)
        session.flush(env.mjai_log)
        self.assertEqual(env.mjai_log[-1]['type'], 'end_game')
        self.assertGreater(checked, 20)
        (B / 'original-ai-fullgame-check.json').write_text(json.dumps(dict(
            passed=True, decisions_checked=checked, complete_halfgame=True,
            original_action_fidelity=True, native_weights_sha256=original.WEIGHT_SHA256,
            scores=list(env.scores()), ranks=list(env.ranks()), credentials_used=False,
            real_platform_login_tested=False), indent=2)+'\n', encoding='utf-8')


if __name__ == '__main__':
    unittest.main(verbosity=2)
