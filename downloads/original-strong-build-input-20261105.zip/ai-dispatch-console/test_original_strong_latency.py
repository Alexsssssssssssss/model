"""Startup-order, event-loop liveness and no-fixed-delay regression tests."""
import asyncio
import json
from pathlib import Path
import tempfile
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import torch

import majsoul_live as m
import original_strong_live as original

B = Path(__file__).resolve().parent
CP = B/'models/original-strong.json'
DATA = dict(chang=0, ju=0, ben=0, liqibang=0, scores=[25000]*4, doras=['4z'],
    tiles=['7z','2m','3m','4m','5m','6m','2p','3p','4p','5p','6p','2s','3s','4s'],
    operation=dict(seat=0, operation_list=[dict(type=1)]))


class LatencyChecks(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1)

    def test_prepared_weights_are_reused_across_seats(self):
        with original._BUNDLE_LOCK:
            original._BUNDLES.clear()
        with patch.object(original, '_load_uncached', wraps=original._load_uncached) as load:
            preparation = original.prepare_original_model(CP)
            sessions = [original.OriginalStrongSession(CP, i) for i in range(4)]
            self.assertEqual(load.call_count, 1)
        self.assertEqual(preparation['status'], 'ready')
        self.assertTrue(all(s.original is sessions[0].original for s in sessions))
        self.assertEqual(len({id(s.bot) for s in sessions}), 4)

    def test_model_preparation_finishes_before_login_or_room_entry(self):
        order = []
        prepare = original.prepare_original_model
        def wrapped(path):
            order.append('prepare')
            return prepare(path)
        def gateway():
            order.append('gateway')
            return dict(resource='0.16.283', package='4.0.47', client_version_string='WebGL_2022-0.16.283'), 'wss://route-2.maj-soul.com'
        class RPC:
            def __init__(self, codec):
                pass
            async def open(self, url):
                order.append('open')
            async def call(self, name, data):
                order.append(name)
                if name.endswith('requestConnection'):
                    return dict(result=1)
                raise RuntimeError('synthetic stop before credentials are used')
            async def close(self):
                pass
        with tempfile.TemporaryDirectory() as folder, patch.object(original, 'prepare_original_model', wrapped), patch.object(m, 'gateway', gateway), patch.object(m, 'RPC', RPC):
            client = m.SoulRoomClient('synthetic-account', 'synthetic-password', 'balanced', CP, 12345, output=folder)
            with self.assertRaisesRegex(RuntimeError, 'synthetic stop'):
                asyncio.run(client.run())
            self.assertEqual(order[0], 'prepare')
            self.assertLess(order.index('prepare'), order.index('.lq.Lobby.login'))
            self.assertEqual(client.diagnostic['model_preparation']['status'], 'ready')

    def test_slow_inference_does_not_block_event_loop(self):
        async def run():
            started, release = threading.Event(), threading.Event()
            loop_thread = threading.get_ident()
            worker_threads = []
            def choose(operation):
                worker_threads.append(threading.get_ident())
                started.set()
                if not release.wait(5):
                    raise RuntimeError('Event loop could not release inference')
                return None
            client = m.SoulRoomClient('synthetic', 'synthetic', 'balanced', None, 12345, output=B)
            client.policy = SimpleNamespace(seat=0, event=lambda e: None, choose=choose)
            task = asyncio.create_task(client.action('ActionDealTile', dict(seat=0, tile='1m')))
            while not started.is_set():
                await asyncio.sleep(.001)
            release.set()
            await task
            self.assertNotEqual(worker_threads[0], loop_thread)
        asyncio.run(run())

    def test_cancellation_waits_for_native_worker_to_finish(self):
        async def run():
            entered, release, finished = threading.Event(), threading.Event(), threading.Event()
            def choose(operation):
                entered.set()
                release.wait(5)
                finished.set()
                return None
            client = m.SoulRoomClient('synthetic', 'synthetic', 'balanced', None, 12345, output=B)
            client.policy = SimpleNamespace(seat=0, event=lambda e: None, choose=choose)
            task = asyncio.create_task(client.action('ActionDealTile', dict(seat=0, tile='1m')))
            while not entered.is_set():
                await asyncio.sleep(.001)
            task.cancel()
            await asyncio.sleep(.005)
            self.assertFalse(task.done())
            release.set()
            with self.assertRaises(asyncio.CancelledError):
                await task
            self.assertTrue(finished.is_set())
        asyncio.run(run())

    def test_actual_first_discard_has_no_fixed_sleep_and_keeps_timing(self):
        async def run():
            await asyncio.to_thread(original.prepare_original_model, CP)
            client = m.SoulRoomClient('synthetic', 'synthetic', 'balanced', CP, 12345, output=B)
            client.policy = m.SoulPolicy(CP, 0)
            client.policy.event(dict(type='start_game', names=['player']*4, id=0))
            calls, sleeps = [], []
            class Game:
                async def call(self, method, request):
                    calls.append(request)
            client.game = Game()
            original_sleep = asyncio.sleep
            async def observe_sleep(seconds):
                sleeps.append(seconds)
                await original_sleep(0)
            with patch.object(m.asyncio, 'sleep', observe_sleep):
                await client.action('ActionNewRound', DATA)
            self.assertEqual(sleeps, [0])
            self.assertEqual(calls[0]['tile'], '7z')
            timing = client.diagnostic['decision_timing'][-1]
            self.assertEqual(timing['artificial_delay_seconds'], 0.)
            self.assertEqual(timing['native_inference']['torch_threads'], 1)
            self.assertIn('rpc_seconds', timing)
        asyncio.run(run())


if __name__ == '__main__':
    unittest.main(verbosity=2)
