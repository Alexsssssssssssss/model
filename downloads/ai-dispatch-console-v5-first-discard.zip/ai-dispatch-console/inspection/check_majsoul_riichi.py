"""Native-engine riichi candidate and first-discard regressions; no live login."""
import asyncio
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch
import torch
B=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(B))
import majsoul_live as m
from dispatch_server import models
from live_policy import load_policy
from majsoul_protocol import Codec

torch.set_num_threads(2)
class Preference:
 def __init__(self,encoding,preferred=27):self.encoding=encoding;self.preferred=preferred
 def __call__(self,x,mask):
  logits=torch.zeros_like(mask,dtype=torch.float32)
  logits[:,self.preferred]=90;logits[:,37]=100
  return logits.masked_fill(~mask,-1e9)

HAND=['1m','2m','3m','4m','5m','6m','1p','2p','3p','4s','5s','6s','E']
class RiichiChecks(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.model=load_policy(models()['balanced-focus-v5']['path'])
 def policy(self,hand=None,draw='S',prefer=27):
  p=m.SoulPolicy.__new__(m.SoulPolicy)
  p.seat=0;p.env=m.RiichiEnv(game_mode=int(m.GameType.YON_HANCHAN),rule=m.GameRule.default_mjsoul())
  p.obs=None;p.events=[];p.pending_reach=False;p.decision_count=0
  p.model=Preference(self.model.encoding,prefer)
  p.event(dict(type='start_game',id=0,names=['player']*4))
  p.event(dict(type='start_kyoku',bakaze='E',kyoku=1,honba=0,kyotaku=0,oya=0,dora_marker='N',tehais=[hand or HAND]+[['?']*13]*3,scores=[25000]*4))
  p.event(dict(type='tsumo',actor=0,pai=draw))
  return p
 def operation(self,choices):return {'seat':0,'operation_list':[{'type':1},{'type':7,'combination':choices}]}
 def test_server_subset_masks_preferred_local_discard(self):
  p=self.policy();req=p.choose(self.operation(['2z']))
  self.assertEqual(req,{'type':7,'tile':'2z','moqie':True})
  self.assertTrue(p.pending_reach)
  self.assertEqual(sum(e['type']=='reach' for e in p.events),1)
 def test_declared_hand_discard_is_not_tsumogiri(self):
  req=self.policy(prefer=28).choose(self.operation(['1z']))
  self.assertEqual(req,{'type':7,'tile':'1z','moqie':False})
 def test_red_and_normal_five_server_identity_all_suits(self):
  for suit in 'mps':
   hand=['1m','2m','3m','1p','2p','3p','1s','2s','3s','7s','8s','9s','5'+suit]
   for choice in ['0'+suit,'5'+suit]:
    with self.subTest(suit=suit,choice=choice):
     req=self.policy(hand,'5'+suit+'r').choose(self.operation([choice]))
     self.assertEqual(req['type'],7);self.assertEqual(req['tile'],choice)
     self.assertEqual(req['moqie'],choice.startswith('0'))
 def test_keep_red_when_both_permitted(self):
  for suit in 'mps':
   hand=['1m','2m','3m','1p','2p','3p','1s','2s','3s','7s','8s','9s','5'+suit]
   p=self.policy(hand,'5'+suit+'r',prefer=34+'mps'.index(suit))
   self.assertEqual(p.choose(self.operation(['0'+suit+'|5'+suit]))['tile'],'5'+suit)
 def test_missing_or_disjoint_candidates_fall_back_without_mutation(self):
  for choices in [[],None,['9p']]:
   with self.subTest(choices=choices):
    p=self.policy();before=list(p.events)
    req=p.choose(self.operation(choices))
    self.assertEqual(req['type'],1);self.assertFalse(p.pending_reach);self.assertEqual(p.events,before)
 def test_no_normal_operation_no_invented_fallback(self):
  p=self.policy();before=list(p.events)
  with self.assertRaisesRegex(RuntimeError,'没有交集'):
   p.choose({'seat':0,'operation_list':[{'type':7,'combination':['9p']}]})
  self.assertFalse(p.pending_reach);self.assertEqual(p.events,before)
 def test_server_other_seat_ignored(self):
  p=self.policy();op=self.operation(['2z']);op['seat']=1
  self.assertIsNone(p.choose(op));self.assertFalse(p.pending_reach)
 def test_request_codec_round_trip(self):
  req=self.policy().choose(self.operation(['2z']));codec=Codec(live=True)
  method=m.operation_method(req,self.operation(['2z']));typ=codec.method(method)['requestType']
  decoded=codec.decode(typ,codec.encode(typ,req))
  for key in req:self.assertEqual(decoded[key],req[key])
 def test_real_v5_inference_respects_subset(self):
  p=self.policy();p.model=self.model
  # Normal mode may choose not to riichi. Restrict the server operations to
  # riichi to exercise the actual v5's subsequent discard scoring.
  req=p.choose({'seat':0,'operation_list':[{'type':7,'combination':['2z']}]})
  self.assertEqual(req['tile'],'2z');self.assertEqual(req['type'],7)
 def test_reach_echo_not_duplicated(self):
  p=self.policy();req=p.choose(self.operation(['2z']))
  c=m.SoulRoomClient('synthetic','synthetic','balanced',None,12345,output=B/'inspection');c.policy=p
  async def run():
   await c.action('ActionDiscardTile',{'seat':0,'tile':req['tile'],'moqie':req['moqie'],'is_liqi':True})
  asyncio.run(run());self.assertFalse(p.pending_reach)
  self.assertEqual(sum(e['type']=='reach' for e in p.events),1)
 def test_actual_first_discard_routes_missing_null_and_present_operation(self):
  async def run(count,op):
   p=self.policy();p.model=self.model
   c=m.SoulRoomClient('synthetic','synthetic','balanced',None,12345,output=B/'inspection');c.policy=p
   calls=[]
   class Game:
    async def call(self,*args):calls.append(args)
   c.game=Game()
   data=dict(chang=0,ju=0,ben=0,liqibang=0,scores=[25000]*4,doras=['4z'],tiles=['1m','2m','3m','4m','5m','6m','1p','2p','3p','4p','5p','6p','1z','2z'][:count])
   if op!='missing':data['operation']=op
   async def fast_sleep(*args):pass
   with patch.object(m.asyncio,'sleep',fast_sleep):await c.action('ActionNewRound',data)
   self.assertEqual(len(calls),1 if count==14 else 0)
   if calls:self.assertEqual(calls[0][0],'.lq.FastTest.inputOperation');self.assertEqual(calls[0][1]['type'],1)
  for count,op in [(14,'missing'),(14,None),(14,{}),(14,{'seat':0,'operation_list':[{'type':1}]}),(13,'missing')]:
   with self.subTest(count=count,operation=op):asyncio.run(run(count,op))

if __name__=='__main__':unittest.main(verbosity=2)
