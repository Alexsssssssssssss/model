"""Exercise the actual v5 adapter with synthetic Liqi transport; no real login."""
import sys,asyncio,json,base64,tempfile,hmac,hashlib
import numpy as np
import torch
from riichienv import Action,ActionType
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
B=Path(__file__).resolve().parents[1];sys.path.insert(0,str(B))
import majsoul_live as m
from majsoul_protocol import Codec,SoulRPCError
from dispatch_server import models
codec=Codec(live=True)
VERSION=dict(resource='0.16.283',package='4.0.47',client_version_string='WebGL_2022-0.16.283')
request=m.login_request('test-user','test-password',VERSION,1)
roundtrip=codec.decode('ReqLogin',codec.encode('ReqLogin',request))
assert roundtrip['client_version']['resource']=='0.16.283' and roundtrip['tag']=='cn' and roundtrip['type']==1
assert roundtrip['password']==hmac.new(b'lailai',b'test-password',hashlib.sha256).hexdigest()
assert 'session' not in codec.schema['ReqAuthGame']['fields']
assert roundtrip['client_version']['package']=='4.0.47' and roundtrip['client_version_string']=='WebGL_2022-0.16.283'
assert codec.encode('ReqRequestConnection',dict(type=1,route_id='route-2',timestamp=1791910000,platform='Web')).endswith(b'\x32\x03Web')
for typ,expected in [(1,'inputOperation'),(2,'inputChiPengGang'),(3,'inputChiPengGang'),(4,'inputOperation'),(5,'inputChiPengGang'),(6,'inputOperation'),(7,'inputOperation'),(8,'inputOperation'),(9,'inputChiPengGang')]:
 req={'type':typ};method=m.operation_method(req,{'operation_list':[{'type':typ}]});assert method.endswith(expected);codec.encode(codec.method(method)['requestType'],req)
assert m.operation_method({'cancel_operation':True},{'operation_list':[{'type':9}]}).endswith('inputChiPengGang')
class FakeRPC:
 instances=[];fail=False
 def __init__(self,codec):self.codec=codec;self.notifications=asyncio.Queue();self.calls=[];self.closed=False;self.round_index=0;self.instances.append(self)
 def notify(self,name,data):
  raw=self.codec.encode(name,data);keys=(132,94,78,66,57,162,31,96,28);encrypted=bytes(v^(((23^len(raw))+5*i+keys[i%9])&255) for i,v in enumerate(raw));self.notifications.put_nowait(('lq.ActionPrototype',dict(name=name,data=base64.b64encode(encrypted).decode())))
 async def open(self,url):self.url=url;return self
 async def call(self,name,data=None):
  self.calls.append((name,data));self.codec.encode(self.codec.method(name)['requestType'],data or {})
  if name.endswith('.requestConnection'):
   assert data['platform']=='Web' and data['route_id']=='route-2' and data['timestamp']<100000000000
   return {'result':1}
  if name.endswith('.login'):
   assert self.calls[-2][0].endswith('.requestConnection')
   assert data['client_version_string']=='WebGL_2022-0.16.283'
   if self.fail:raise SoulRPCError(name,151)
   return {'account_id':123,'access_token':'synthetic-never-saved'}
  if name.endswith('.joinRoom'):return {'room':{'max_player_count':4,'mode':{'mode':2,'detail_rule':{'dora_count':3}}}}
  if name.endswith('.readyPlay'):self.notifications.put_nowait(('lq.NotifyRoomGameStart',{'location':'zone','connect_token':'synthetic-connect-secret','game_uuid':'synthetic-game'}))
  if name.endswith('.authGame'):assert 'device' in data and 'session' not in data;return {'seat_list':[123,124,125,126]}
  if name.endswith('.enterGame'):
   self.notify('ActionMJStart',{})
   self.notify('ActionNewRound',dict(chang=self.round_index//4,ju=self.round_index%4,ben=0,liqibang=0,scores=[25000]*4,doras=['4z'],tiles=['1m','2m','3m','4m','5m','6m','1p','2p','3p','4p','5p','6p','1z','2z'],operation={'seat':0,'operation_list':[{'type':1}]}))
  if name.endswith('.inputOperation'):
   assert data['type']==1
   self.notify('ActionDiscardTile',dict(seat=0,tile=data['tile'],moqie=data['moqie']))
   self.notify('ActionNoTile',dict(scores=[{'delta_scores':[0]*4}],gameend=self.round_index==7))
   if self.round_index==7:self.notifications.put_nowait(('lq.NotifyGameEndResult',{'result':{'players':[]}}))
  if name.endswith('.confirmNewRound'):
   assert self.round_index<7
   self.round_index+=1
   self.notify('ActionNewRound',dict(chang=self.round_index//4,ju=self.round_index%4,ben=0,liqibang=0,scores=[25000]*4,doras=['4z'],tiles=['1m','2m','3m','4m','5m','6m','1p','2p','3p','4p','5p','6p','1z','2z'],operation={'seat':0,'operation_list':[{'type':1}]}))
  return {}
 async def close(self):self.closed=True
async def check():
 FakeRPC.instances=[]
 with tempfile.TemporaryDirectory(dir=B/'inspection') as d:
  root=Path(d)
  with patch.object(m,'RPC',FakeRPC),patch.object(m,'gateway',lambda:(VERSION,'wss://route-2.maj-soul.com')):
   client=m.SoulRoomClient('test-user','test-password','balanced',models()['balanced-focus-v5']['path'],11507,output=root/'success',login_type=1)
   result=await client.run();assert result['own_seat']==0 and client.policy.decision_count==8
   assert sum(e['type']=='start_kyoku' for e in client.policy.events)==8
   assert sum(e['type']=='end_game' for e in client.policy.events)==1
   assert sum(n.endswith('.confirmNewRound') for n,d in client.game.calls)==7
   assert sum(e['type']=='start_game' for e in client.policy.events)==1
   assert all(r.closed for r in FakeRPC.instances)
   saved=''.join(p.read_text() for p in (root/'success').iterdir())
   for secret in ['test-user','test-password','synthetic-never-saved','synthetic-connect-secret']:assert secret not in saved
   FakeRPC.fail=True
   client=m.SoulRoomClient('test-user','test-password','balanced',models()['balanced-focus-v5']['path'],11507,output=root/'failed')
   try:await client.run();raise AssertionError('Expected login error')
   except SoulRPCError as exc:assert exc.code==151
   diag=json.loads((root/'failed/diagnostics.json').read_text());assert diag['error_code']==151 and diag['stage']=='logging_in' and 'test-user' not in json.dumps(diag)
   events=[dict(type='pon',actor=1,target=2,pai='5p',consumed=['5p','5pr'])]
   client.policy=SimpleNamespace(seat=0,obs=None,events=events,event=lambda e:events.append(e),choose=lambda op:None)
   client.game=FakeRPC(codec);client.last_discard=(2,'E')
   await client.action('ActionAnGangAddGang',dict(seat=1,type=3,tiles='5p'))
   await client.action('ActionHule',dict(scores=[26000,24000,25000,25000],delta_scores=[1000,-1000,0,0],hules=[dict(seat=0,zimo=False)]))
   assert next(e for e in events if e['type']=='hora')['target']==1
# Test real native win actions: their MJAI JSON deliberately has no actor/target.
for action_type,code in [(ActionType.TSUMO,8),(ActionType.RON,9)]:
 action=Action(action_type)
 assert json.loads(action.to_mjai())=={'type':'hora'}
 policy=m.SoulPolicy.__new__(m.SoulPolicy);policy.seat=0;policy.obs=SimpleNamespace();policy.decision_count=0
 policy.model=SimpleNamespace(encoding='test',__call__=None)
 class WinModel:
  encoding='test'
  def __call__(self,x,mask):return torch.tensor([[1.]])
 policy.model=WinModel()
 with patch.object(m,'tensors',return_value=(np.zeros(1,dtype=np.float32),np.ones(1,dtype=bool),{0:[action]})),patch.object(m,'retain_red_fives',side_effect=lambda obs,allowed:allowed),patch.object(m,'resolve',return_value=action):
  assert policy.choose({'seat':0,'operation_list':[{'type':code}]})=={'type':code}
async def terminal_checks():
 client=m.SoulRoomClient('test-user','test-password','balanced',models()['balanced-focus-v5']['path'],11507,output=B/'inspection')
 events=[];client.policy=SimpleNamespace(seat=0,obs=None,events=events,event=lambda e:events.append(e),choose=lambda op:None);client.game=FakeRPC(codec)
 # Single self-draw, ron, double ron, exhaustive and abortive draws do not finish a match.
 for name,data in [
 ('ActionHule',dict(scores=[25000]*4,delta_scores=[0]*4,hules=[dict(seat=0,zimo=True)])),
 ('ActionHule',dict(scores=[25000]*4,delta_scores=[0]*4,hules=[dict(seat=0,zimo=False)])),
 ('ActionHule',dict(scores=[25000]*4,delta_scores=[0]*4,hules=[dict(seat=0,zimo=False),dict(seat=2,zimo=False)])),
 ('ActionNoTile',dict(scores=[{'delta_scores':[0]*4}])),('ActionLiuJu',{})]:
  client.last_discard=(1,'5p');client.final_scores=[25000]*4;client.game.round_index=0
  before=len(client.game.calls);await client.action(name,data)
  assert len(client.game.calls)==before+1 and client.result is None
  assert events[-1]['type']=='end_kyoku' and not any(e['type']=='end_game' for e in events)
 # Final win and final draw must wait for authoritative match result, without next-round requests.
 for name,data in [('ActionHule',dict(scores=[25000]*4,delta_scores=[0]*4,hules=[dict(seat=0,zimo=True)],gameend={'scores':[25000]*4})),('ActionNoTile',dict(scores=[],gameend=True)),('ActionLiuJu',dict(gameend={'scores':[25000]*4}))]:
  before=len(client.game.calls);await client.action(name,data)
  assert len(client.game.calls)==before and client.result is None
asyncio.run(terminal_checks())
asyncio.run(check())
report={'passed':True,'v5_actual_legal_decision':True,'ActionMJStart_before_first_round':True,'login_fields_protocol_roundtrip':True,'reaction_rpc_routing':True,'mock_login_room_game_completion':True,'error_151_stage_diagnostics':True,'credential_redaction':True,'native_tsumo_ron_mapping':True,'eight_rounds_final_draw':True,'single_double_ron_and_abortive_draw':True,'terminal_waits_for_server_result':True,'real_account_login_tested':False,'real_full_match_tested':False}
(B/'inspection/majsoul-dispatch-check.json').write_text(json.dumps(report,indent=2));print(report)
