import sys,io,asyncio,urllib.error,ssl,concurrent.futures
from pathlib import Path
from unittest.mock import patch
B=Path(__file__).resolve().parents[1];sys.path.insert(0,str(B))
import majsoul_version as v
from majsoul_protocol import RPC
# Only idempotent public GETs are retried, never credential/login or operation RPCs.
refused=ConnectionRefusedError('refused');refused.winerror=10061
with patch.object(v.urllib.request,'urlopen',side_effect=urllib.error.URLError(refused)) as request,patch.object(v.time,'sleep'):
 try:v.read_public('https://game.maj-soul.com/1/?secret=never-recorded');raise AssertionError
 except v.PublicFetchError as e:
  assert e.details['attempts']==3 and e.details['winerror']==10061 and 'secret' not in str(e) and 'secret' not in str(e.details)
 assert request.call_count==3
with patch.object(v.urllib.request,'urlopen',side_effect=urllib.error.URLError(ssl.SSLCertVerificationError('bad certificate'))) as request:
 try:v.read_public('https://game.maj-soul.com/1/');raise AssertionError
 except v.PublicFetchError as e:assert e.details['attempts']==1
 assert request.call_count==1
v._VERSION_CACHE=None
with patch.object(v,'_resolve_client_version',return_value={'resource':'0.16.283'}) as resolver:
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:results=list(executor.map(lambda _:v.resolve_client_version(),range(2)))
 assert resolver.call_count==1 and results[0]==results[1]
v._VERSION_CACHE=None
class Socket:
 close_code=1000
 def __aiter__(self):return self
 async def __anext__(self):raise StopAsyncIteration
async def check():
 rpc=RPC(None);rpc.ws=Socket();future=asyncio.get_running_loop().create_future();rpc.pending[1]=('unused',future)
 await rpc.read();name,data=await rpc.notifications.get();assert name=='connection_closed' and data['close_code']==1000 and data['error_type']=='CleanWebSocketClosure'
 try:await future;raise AssertionError
 except ConnectionError:pass
 assert not rpc.pending
asyncio.run(check())
print('Passed: public GET retries, URL redaction, certificate verification preserved, simultaneous version cache, clean WebSocket closure and pending request cleanup')
