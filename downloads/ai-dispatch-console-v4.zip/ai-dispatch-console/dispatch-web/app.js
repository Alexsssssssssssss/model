'use strict';
const $=s=>document.querySelector(s);let state=null,botRows=[{model:'supervised-v4',account:'',learn:false,goal:'balanced'}],tab='dispatch';
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const platform=()=>$('input[name=platform]:checked').value,mode=()=>$('input[name=mode]:checked').value;
const statuses={starting:'启动中',running:'运行中',stopping:'停止中',stopped:'已停止',completed:'已完成',error:'出现错误',connecting:'连接中',waiting_in_private_room:'已登录，预约中',playing:'对局中',stopped_on_error:'已停止'};
function notice(text){$('#toast').textContent=text;$('#toast').hidden=false;setTimeout(()=>$('#toast').hidden=true,4000)}
function error(selector,message){$(selector).textContent=message;$(selector).hidden=!message}
async function api(path,data){const res=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-Console-Token':state.token},body:JSON.stringify(data)});const reply=await res.json();if(!res.ok)throw Error(reply.error||'操作失败');return reply}
function switchTab(name){tab=name;document.querySelectorAll('.pane').forEach(e=>e.hidden=e.id!==name);document.querySelectorAll('nav button').forEach(e=>e.classList.toggle('active',e.dataset.tab===name))}
document.addEventListener('click',e=>{const t=e.target.closest('[data-tab]');if(t)switchTab(t.dataset.tab)});
function renderBots(){if(!state)return;const accounts=state.accounts.filter(a=>a.platform===platform());$('#bots').innerHTML=botRows.map((r,i)=>`<div class="bot"><div class="bot-top"><span>AI ${i+1}</span>${mode()==='invite'&&botRows.length>1?`<button type="button" class="remove" data-remove="${i}">移除</button>`:''}</div><div class="bot-grid"><label>模型<select aria-label="AI ${i+1} 模型" data-i="${i}" data-key="model">${state.models.map(m=>`<option value="${escape(m.id)}" ${m.id===r.model?'selected':''}>${escape(m.label)}${m.stage==='待实战验证'?'（待实战）':''}</option>`).join('')}</select></label><label>本机账号<select aria-label="AI ${i+1} 账号" data-i="${i}" data-key="account"><option value="">选择账号</option>${accounts.map(a=>`<option value="${escape(a.key)}" ${a.key===r.account?'selected':''}>${escape(a.label)}</option>`).join('')}</select></label></div>${mode()==='rl'?`<div class="learning"><label><input type="checkbox" data-i="${i}" data-key="learn" ${r.learn?'checked':''}> 参与学习</label><select aria-label="AI ${i+1} 学习目标" data-i="${i}" data-key="goal">${Object.entries({avoid_fourth:'避四',balanced:'平衡',first_place:'争一'}).map(([k,v])=>`<option value="${k}" ${r.goal===k?'selected':''}>${v}</option>`).join('')}</select><span>${r.learn?'半庄结束后更新':'冻结模型作为对手'}</span></div>`:''}</div>`).join('');$('#add-bot').hidden=mode()!=='invite'||botRows.length>=3}
$('#bots').addEventListener('change',e=>{const i=Number(e.target.dataset.i),key=e.target.dataset.key;if(!key)return;botRows[i][key]=key==='learn'?e.target.checked:e.target.value;if(key==='learn')renderBots()});$('#bots').addEventListener('click',e=>{if(e.target.dataset.remove!==undefined){botRows.splice(Number(e.target.dataset.remove),1);renderBots()}});
$('#add-bot').onclick=()=>{if(botRows.length<3){botRows.push({model:state.models[botRows.length%state.models.length].id,account:'',learn:false,goal:'balanced'});renderBots()}};
function configure(){const m=mode(),p=platform();if(m!=='invite'){while(botRows.length<4)botRows.push({model:state.models[botRows.length%state.models.length].id,account:'',learn:botRows.length<3,goal:['avoid_fourth','balanced','first_place','balanced'][botRows.length]})}else if(botRows.length>3)botRows=botRows.slice(0,3);$('#games-field').hidden=m==='invite';$('#mode-note').textContent=m==='invite'?'最多派遣 3 位 AI，留一个座位给你。':m==='rl'?'需要 4 个独立账号；保留至少一位冻结模型。随机探索会影响对战强度。':'需要 4 个独立账号；只收集对战数据，不更新模型。';$('#room-label').textContent=p==='tenhou'?'天凤个室号':'雀魂友人房号';$('#room').placeholder=p==='tenhou'?'1000–9999':'请输入友人房号';$('#room').min=p==='tenhou'?'1000':'1';$('#room').max=p==='tenhou'?'9999':'99999999';$('#platform-warning').hidden=p==='tenhou';$('#platform-warning').textContent=state.capabilities.majsoul_reason;$('#submit').disabled=p==='majsoul'&&m!=='invite';$('#submit').textContent=p==='majsoul'&&m!=='invite'?'雀魂暂不支持内战训练':m==='invite'?'派遣 AI 到房间':m==='rl'?'开始四 AI 强化学习':'开始四 AI 内战';renderBots()}
document.querySelectorAll('input[name=platform],input[name=mode]').forEach(e=>e.onchange=configure);
$('#dispatch-form').onsubmit=async e=>{e.preventDefault();error('#dispatch-error','');$('#submit').disabled=true;try{await api('/api/dispatch',{platform:platform(),mode:mode(),room:Number($('#room').value),games:mode()==='invite'?1:Number($('#games').value),bots:botRows});switchTab('tasks');await refresh();notice('派遣任务已创建')}catch(e){error('#dispatch-error',e.message)}finally{$('#submit').disabled=platform()==='majsoul'&&mode()!=='invite'}};
function renderAccounts(){$('#account-list').innerHTML=state.accounts.length?state.accounts.map(a=>`<div class="account-row"><div>${escape(a.label)}<span>${a.platform==='tenhou'?'天凤':'雀魂'}</span></div><button class="remove" type="button" data-delete="${escape(a.key)}">删除</button></div>`).join(''):'<div class="empty">还没有本机账号，请先添加。</div>'}
$('#account-platform').onchange=()=>{const soul=$('#account-platform').value==='majsoul';$('#login-label').textContent=soul?'雀魂账号':'天凤完整登录 ID';$('#account-login').setAttribute('aria-label',soul?'雀魂账号':'天凤完整登录 ID');$('#account-login').placeholder=soul?'账号':'IDxxxxxxxx-xxxxxxxx';$('#password-field').hidden=!soul;$('#account-password').required=soul;$('#login-hint').textContent=soul?'仅保存在本机；雀魂为实验接入，仅支持国服标准四人半庄友人房。':'使用登录 ID，不能填写玩家昵称。'};
$('#account-form').onsubmit=async e=>{e.preventDefault();error('#account-error','');try{await api('/api/accounts',{platform:$('#account-platform').value,label:$('#account-label').value,login:$('#account-login').value,password:$('#account-password').value});$('#account-login').value='';$('#account-password').value='';await refresh();renderBots();notice('账号已保存到本机')}catch(e){error('#account-error',e.message)}};
$('#account-list').onclick=async e=>{if(!e.target.dataset.delete)return;if(!confirm('删除这个本机账号配置？'))return;try{await api('/api/accounts/delete',{key:e.target.dataset.delete});await refresh();renderBots()}catch(e){notice(e.message)}};
function renderTasks(){$('#task-list').innerHTML=state.tasks.length?state.tasks.map(t=>`<article class="task"><div class="task-title"><h2>${t.platform==='tenhou'?'天凤个室':'雀魂友人房'} ${t.room} · ${t.mode==='invite'?'邀请对战':t.mode==='rl'?'强化学习':'四 AI 内战'}</h2><span class="status">${statuses[t.status]||escape(t.status)}</span></div><p class="task-meta">完成 ${t.completed} / ${t.target} 把${t.mode==='rl'?` · 更新 ${t.updates} 次`:''}</p>${t.bots.map(b=>`<div class="bot-state">AI ${b.index+1} · ${escape(b.account_label)} · ${escape(b.model_label)} — ${escape(statuses[b.status]||b.status)}</div>`).join('')}${t.error?`<div class="error" role="alert">${escape(t.error)}</div>`:''}${t.note?`<p class="hint">${escape(t.note)}</p>`:''}${t.statistics.length?`<div class="scroll-table"><table><thead><tr><th>AI</th><th>半庄</th><th>平均顺位</th><th>副露率</th><th>立直率</th><th>和牌率</th><th>放铳率</th></tr></thead><tbody>${t.statistics.map(s=>`<tr><td>${s.bot}</td><td>${s.half_games}</td><td>${s.mean_rank?.toFixed(3)||'—'}</td>${['open_rate','riichi_rate','win_rate','deal_in_rate'].map(k=>`<td>${s[k]==null?'—':(s[k]*100).toFixed(1)+'%'}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`:''}<div class="task-actions">${['starting','running','stopping'].includes(t.status)?`<button class="secondary" data-stop="${t.id}" ${t.status==='stopping'?'disabled':''}>停止任务</button>`:''}<a class="link" href="/api/statistics/${t.id}" download="${t.id}-statistics.csv">下载统计 CSV</a></div></article>`).join(''):'<div class="empty">还没有对战任务。选择房间后即可派遣。</div>'}
$('#task-list').onclick=async e=>{if(!e.target.dataset.stop)return;try{await api('/api/stop',{id:e.target.dataset.stop});await refresh()}catch(e){notice(e.message)}};
async function refresh(){try{const r=await fetch('/api/state');if(!r.ok)throw Error('服务异常');state=await r.json();$('#service').textContent=state.tasks.some(t=>['running','starting'].includes(t.status))?'对战中':'空闲';$('#service-note').textContent=`${state.models.length} 个模型 · ${state.accounts.length} 个本机账号`;renderAccounts();renderTasks()}catch(e){$('#service').textContent='服务已断开';$('#service-note').textContent='请检查启动窗口是否仍在运行'}}
(async()=>{await refresh();if(state){if(!state.models.some(m=>m.id===botRows[0].model))botRows[0].model=state.models[0]?.id||'';configure()}setInterval(refresh,3000)})();

// Versioned task diagnostics also work for unfinished tasks saved by older builds.
const renderTasksBase=renderTasks;
renderTasks=function(){
  renderTasksBase();
  document.querySelectorAll('#task-list article.task').forEach((card,index)=>{
    const task=state.tasks[index],actions=card.querySelector('.task-actions');
    const download=document.createElement('a');download.className='link';
    download.href='/api/diagnostics/'+task.id;download.download=task.id+'-diagnostics.zip';
    download.textContent='下载诊断记录';actions.append(download);
    if(task.error_context){
      const note=document.createElement('p');note.className='hint';
      note.textContent='出错 AI '+task.error_context.bot+' · 阶段 '+(statuses[task.error_context.phase]||task.error_context.phase||'未知');
      card.insertBefore(note,actions);
    }
    card.querySelectorAll('.bot-state').forEach((row,i)=>{
      const bot=task.bots[i];
      if(bot.selection_mode){
        row.append(document.createTextNode(bot.selection_mode==='sampled'?' · 随机探索 T='+bot.temperature:' · 确定性决策'));
      }
      if(bot.checkpoint_sha256){
        const detail=document.createElement('small');detail.textContent=' · 版本 '+bot.checkpoint_sha256.slice(0,12);row.append(detail);
      }
      if(String(bot.replay_url||'').startsWith('https://tenhou.net/')){
        const link=document.createElement('a');link.className='link';link.href=bot.replay_url;
        link.target='_blank';link.rel='noopener';link.textContent=' 查看牌谱';row.append(link);
      }
    });
  });
};
