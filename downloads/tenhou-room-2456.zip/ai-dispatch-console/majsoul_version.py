"""Resolve CN Unity WebGL package and resource versions from official assets."""
import json,re,time,urllib.request,warnings
from pathlib import PurePosixPath
BASE='https://game.maj-soul.com'

def read_public(url):
 sep='&' if '?' in url else '?'
 req=urllib.request.Request(url+sep+'randv='+str(time.time_ns()),headers={'User-Agent':'Mozilla/5.0','Cache-Control':'no-cache','If-Modified-Since':'0'})
 with urllib.request.urlopen(req,timeout=25) as response:
  data=response.read(16*1024*1024+1)
 if len(data)>16*1024*1024:raise ValueError('雀魂版本配置超过读取上限')
 return data

def bundle_objects(raw):
 import UnityPy
 from UnityPy.exceptions import UnityVersionFallbackWarning
 # Public bundles strip the engine version to 0.0.0; the official build is Unity 2022.3.
 UnityPy.config.FALLBACK_UNITY_VERSION='2022.3.62f2'
 with warnings.catch_warnings():
  warnings.simplefilter('ignore',UnityVersionFallbackWarning)
  return list(UnityPy.load(raw).objects)

def resolve_client_version():
 html=read_public(BASE+'/1/').decode('utf-8')
 match=re.search(r'productVersion\s*:\s*[\"\'](\d+\.\d+\.\d+)[\"\']',html)
 if 'createUnityInstance' not in html or not match:raise ValueError('无法确认雀魂现用Unity客户端版本，已停止；不会使用旧version.json替代')
 package=match.group(1)
 manifest=read_public(BASE+'/assetbundles/ASTC/bundle_info_so.majset')
 info=None
 for obj in bundle_objects(manifest):
  if obj.type.name=='MonoBehaviour':
   tree=obj.read_typetree()
   if 'assetInfos' in tree and 'bundleInfos' in tree:info=tree;break
 if info is None:raise ValueError('雀魂资源索引格式不支持')
 matches=[a for a in info['assetInfos'] if a['assetPath'].replace('\\','/').endswith('/docs_version/version.json')]
 if len(matches)!=1:raise ValueError('未唯一定位雀魂资源版本配置')
 name=info['bundleInfos'][matches[0]['ownerBundleIndex']]['name']
 if PurePosixPath(name).name!=name or not re.fullmatch(r'[A-Za-z0-9_.-]+\.majset',name):raise ValueError('雀魂版本资源文件名无效')
 raw=read_public(BASE+'/assetbundles/ASTC/'+name);resource=None
 for obj in bundle_objects(raw):
  if obj.type.name=='TextAsset':
   asset=obj.read()
   if asset.m_Name=='version':
    data=json.loads(asset.m_Script)
    if data.get('platform')=='WebGL':resource=data.get('version')
 if not isinstance(resource,str) or not re.fullmatch(r'\d+\.\d+\.\d+',resource):raise ValueError('雀魂资源版本配置无效')
 return dict(resource=resource,package=package,client_version_string='WebGL_2022-'+resource,version_bundle=name)

def client_version_string(version):return version['client_version_string']
