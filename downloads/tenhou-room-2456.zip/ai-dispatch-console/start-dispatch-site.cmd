@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  py -3.12 -m venv .venv
  if errorlevel 1 goto error
)
.venv\Scripts\python -c "import torch, numpy, riichienv, websockets, google.protobuf" >nul 2>&1
if errorlevel 1 (
  .venv\Scripts\python -m pip install torch --index-url https://download.pytorch.org/whl/cpu
  if errorlevel 1 goto error
  .venv\Scripts\python -m pip install numpy riichienv==0.4.10 websockets==15.0.1 "protobuf>=5,<7"
  if errorlevel 1 goto error
)
if not exist dispatch-site.local.json (
  .venv\Scripts\python public_dispatch_server.py --setup
  if errorlevel 1 goto error
)
.venv\Scripts\python public_dispatch_server.py
if errorlevel 1 goto error
exit /b 0
:error
echo Startup failed. See the error above. Requires Python 3.12.
pause
exit /b 1
