"""Invitation website with admin-only local account pool and owned visitor tasks."""
import argparse,json,secrets,time,hashlib,hmac,getpass,os,threading,webbrowser
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from http.cookies import SimpleCookie
from urllib.parse import urlsplit
from dispatch_server import Console,atomic_json,BASE
WEB=BASE/'public-web'
def hash_password(password,salt):return hashlib.pbkdf2_hmac('sha256',password.encode(),bytes.fromhex(salt),240000).hex()
def setup(root):
 path=root/'dispatch-site.local.json'
 if path.exists():raise SystemExit('网站配置已存在；不会覆盖。')
 config={};used=set()
 for name,label in [('admin','管理员'),('invite','用户邀请')]:
  password=getpass.getpass(label+'口令（至少12个字符，不回显）: ')
  if len(password)<12:raise SystemExit('口令长度不足')
  if password in used:raise SystemExit('管理员口令与邀请口令必须不同')
  used.add(password)
  if getpass.getpass('再次输入: ')!=password:raise SystemExit('两次口令不同')
  salt=secrets.token_hex(16);config[name]={'salt':salt,'hash':hash_password(password,salt)}
 atomic_json(path,config,True)
 print('网站口令已保存为哈希；账号仍在本机账号文件中。')
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def respond(self,data,status=200,mime='application/json; charset=utf-8',cookie=None):
  raw=json.dumps(data,ensure_ascii=False).encode() if isinstance(data,(dict,list)) else data
  self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; frame-ancestors 'none'")
  if cookie:self.send_header('Set-Cookie',cookie)
  self.end_headers();self.wfile.write(raw)
 def host_ok(self):return self.headers.get('Host')==urlsplit(self.server.origin).netloc
 def session(self):
  cookies=SimpleCookie()
  try:cookies.load(self.headers.get('Cookie',''))
  except Exception:return None
  key=cookies['mj_session'].value if 'mj_session' in cookies else None
  with self.server.lock:
   row=self.server.sessions.get(key)
   return row if row and row['expires']>time.time() else None
 def owned_task(self,session,ident):
  with self.server.console.lock:
   t=self.server.console.tasks.get(ident)
   if not t or not (session['admin'] or t.get('visitor_owner')==session['owner']):raise PermissionError('任务不可访问')
   return t
 def do_GET(self):
  if not self.host_ok():return self.respond({'error':'Host无效'},403)
  path=self.path.split('?',1)[0]
  if path=='/api/state':
   session=self.session()
   if not session:return self.respond({'authenticated':False})
   c=self.server.console;snapshot=c.snapshot()
   if not session['admin']:
    snapshot['tasks']=[{**{k:t.get(k) for k in ('id','platform','room','status','completed','target','error')},'visitor_owner':t.get('visitor_owner'),'bots':[{k:b[k] for k in ('model_label','status')} for b in t['bots']]} for t in snapshot['tasks']]
   return self.respond({'authenticated':True,'admin':session['admin'],'token':session['token'],'models':snapshot['models'],'accounts':snapshot['accounts'] if session['admin'] else [],'tasks':[t for t in snapshot['tasks'] if session['admin'] or t.get('visitor_owner')==session['owner']]})
  if path.startswith('/api/diagnostics/'):
   session=self.session()
   if not session:return self.respond({'error':'请先登录'},401)
   try:self.owned_task(session,path.rsplit('/',1)[1]);raw=self.server.console.diagnostic_archive(path.rsplit('/',1)[1]);return self.respond(raw,mime='application/zip')
   except (PermissionError,ValueError):return self.respond({'error':'任务不可访问'},403)
  if path.startswith('/api/'):return self.respond({'error':'未找到'},404)
  file=(WEB/('index.html' if path in ('/','/admin') else path.lstrip('/'))).resolve()
  if not file.is_relative_to(WEB.resolve()) or not file.is_file():return self.respond({'error':'未找到'},404)
  return self.respond(file.read_bytes(),mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png'}.get(file.suffix,'application/octet-stream'))
 def do_POST(self):
  if not self.host_ok() or self.headers.get('Origin')!=self.server.origin:return self.respond({'error':'来源无效'},403)
  try:
   size=int(self.headers.get('Content-Length',0))
   if not 0<size<=16384:raise ValueError('请求大小无效')
   data=json.loads(self.rfile.read(size));session=self.session();c=self.server.console
   if self.path=='/api/login':
    ip=self.client_address[0]
    with self.server.lock:
     now=time.time();attempts=[t for t in self.server.attempts.get(ip,[]) if now-t<600]
     if len(attempts)>=10:return self.respond({'error':'尝试过多，请稍后重试'},429)
     attempts.append(now);self.server.attempts[ip]=attempts
    role='admin' if data.get('role')=='admin' else 'invite';secret=self.server.config[role]
    if not hmac.compare_digest(hash_password(str(data.get('password','')),secret['salt']),secret['hash']):return self.respond({'error':'口令错误'},401)
    key=secrets.token_urlsafe(32);session={'owner':secrets.token_urlsafe(24),'admin':role=='admin','token':secrets.token_urlsafe(32),'expires':time.time()+28800}
    with self.server.lock:self.server.sessions[key]=session
    cookie=f'mj_session={key}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800'+('; Secure' if self.server.origin.startswith('https:') else '')
    return self.respond({'ok':True},cookie=cookie)
   if not session:return self.respond({'error':'请先登录'},401)
   if self.headers.get('X-Site-Token')!=session['token']:return self.respond({'error':'请求令牌无效'},403)
   if self.path=='/api/logout':
    with self.server.lock:self.server.sessions={k:v for k,v in self.server.sessions.items() if v is not session}
    return self.respond({'ok':True},cookie='mj_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0')
   if self.path in ('/api/accounts','/api/accounts/delete'):
    if not session['admin']:raise PermissionError('仅管理员可管理账号')
    return self.respond(c.save_account(data) if self.path=='/api/accounts' else c.delete_account(data.get('key')))
   if self.path=='/api/dispatch':
    platform=data.get('platform','tenhou')
    if platform not in ('tenhou','majsoul'):raise ValueError('平台无效')
    models=data.get('models',[])
    if not isinstance(models,list) or not 1<=len(models)<=3 or any(m not in c.registry for m in models):raise ValueError('选择1～3个有效模型')
    with c.lock:
     active=[t for t in c.tasks.values() if t['status'] in ('starting','running','stopping')]
     if any(t.get('visitor_owner')==session['owner'] for t in active):raise ValueError('已有任务运行，请先停止或等它完成')
     busy={r['account'] for t in active for r in t['rows']};available=[a for a in c.accounts if a['platform']==platform and a['key'] not in busy]
     if len(available)<len(models):raise ValueError('空闲AI账号不足，请稍后再试')
     result=c.dispatch({'platform':platform,'mode':'invite','room':data.get('room'),'games':1,'bots':[dict(account=a['key'],model=m) for a,m in zip(available,models)]})
     task=c.tasks[result['id']];task['visitor_owner']=session['owner'];atomic_json(task['folder']/'task.json',c.public(task))
    return self.respond(result)
   if self.path=='/api/stop':self.owned_task(session,data.get('id'));return self.respond(c.stop(data.get('id')))
   return self.respond({'error':'未找到'},404)
  except PermissionError as exc:self.respond({'error':str(exc)},403)
  except (ValueError,KeyError,TypeError) as exc:self.respond({'error':str(exc)},400)
  except Exception:self.respond({'error':'操作失败，请检查服务器日志'},500)
def main():
 p=argparse.ArgumentParser();p.add_argument('--setup',action='store_true');p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=8780);p.add_argument('--origin');p.add_argument('--no-browser',action='store_true');args=p.parse_args()
 if args.setup:return setup(BASE)
 config=BASE/'dispatch-site.local.json'
 if not config.exists():raise SystemExit('先运行 public_dispatch_server.py --setup 设置管理员与邀请口令')
 origin=args.origin or f'http://127.0.0.1:{args.port}'
 if urlsplit(origin).scheme not in ('http','https') or not urlsplit(origin).netloc or urlsplit(origin).path:raise SystemExit('origin必须是网站首页域名，不含路径')
 server=ThreadingHTTPServer((args.host,args.port),Handler);server.console=Console();server.config=json.loads(config.read_text());server.origin=origin;server.sessions={};server.attempts={};server.lock=threading.RLock()
 if not args.no_browser:webbrowser.open(origin)
 print('邀请派遣网站已启动。口令登录后，管理员管理账号，用户选择房间和模型。')
 try:server.serve_forever()
 except KeyboardInterrupt:
  for t in list(server.console.tasks.values()):
   if t['status'] in ('starting','running','stopping'):server.console.stop(t['id'])
 finally:server.server_close()
if __name__=='__main__':main()
