"""Fresh residual policy using the pinned simulator's native action protocol."""
import torch
from torch import nn

class Residual(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.net = nn.Sequential(nn.Conv1d(channels, channels, 3, padding=1), nn.ReLU(), nn.Conv1d(channels, channels, 3, padding=1))
    def forward(self, x):
        return torch.relu(x + self.net(x))

class Policy(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = nn.Sequential(nn.Conv1d(215, 64, 3, padding=1), nn.ReLU(), *[Residual(64) for _ in range(8)])
        self.head = nn.Sequential(nn.Flatten(), nn.Linear(64 * 34, 82))
    def forward(self, x, mask):
        return self.head(self.encoder(x)).masked_fill(~mask, -1e9)
