@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  py -3.12 -m venv .venv
  if errorlevel 1 goto error
  .venv\Scripts\python -m pip install torch --index-url https://download.pytorch.org/whl/cpu
  if errorlevel 1 goto error
  .venv\Scripts\python -m pip install numpy riichienv==0.4.10 websockets==15.0.1
  if errorlevel 1 goto error
)
if not exist tenhou-room-2456.local.json (
  .venv\Scripts\python tenhou_live.py --config tenhou-room-2456.local.json --setup
  if errorlevel 1 goto error
)
.venv\Scripts\python tenhou_live.py --config tenhou-room-2456.local.json --check
if errorlevel 1 goto error
.venv\Scripts\python tenhou_live.py --config tenhou-room-2456.local.json
if errorlevel 1 goto error
pause
exit /b 0
:error
echo Startup failed. See the error above.
pause
exit /b 1
