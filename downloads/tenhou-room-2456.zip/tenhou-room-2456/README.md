# 在天凤个室 2456 与三个自训 AI 对战

本工具接入本项目的避四、平衡、争一模型，三者已合计完成 50,000 个训练半庄。
本次选择较早保存的评估较优模型，不直接使用最后一次训练的权重。
模型和原始数据来源仍为本项目监督训练和自我对局；网关只负责天凤协议。

已验证：天凤当前客户端使用 `wss://b-ww.mjv.jp`，当前云环境通过代理的
WebSocket 握手成功（101）；三个本地模型可加载；私房 JOIN 固定为 `2456,9`；
公开牌谱在线状态测试 511 次合法决策通过。真实账号登录、匹配及一整场在线对战
尚未验证，因为三个真实账号 ID 还没有在本机配置。

## Windows 使用

推荐 Python 3.12（64 位）。解压发布包，在该目录打开终端，运行：

```bat
py -3.12 -m venv .venv
.venv\Scripts\python -m pip install torch --index-url https://download.pytorch.org/whl/cpu
.venv\Scripts\python -m pip install numpy riichienv==0.4.10 websockets==15.0.1
.venv\Scripts\python tenhou_live.py --config tenhou-room-2456.local.json --setup
.venv\Scripts\python tenhou_live.py --config tenhou-room-2456.local.json --check
.venv\Scripts\python tenhou_live.py --config tenhou-room-2456.local.json
```

`--setup` 分别提示输入三个账号的登录 ID（形如 `IDxxxxxxxx-xxxxxxxx`），输入不回显，
只保存本机文件。不要填写你的本人账号；本人从浏览器进入
https://tenhou.net/3/?L2456 ，选择四人半庄、食断、赤牌，点击预约。
三个 AI 账号不要同时在其他客户端登录。AI 每个账号打一场半庄后退出，
不会自动进入其他房间或继续预约。

也可以双击发布包内的 `start-tenhou-2456.cmd`，它会完成依赖安装、首次账号配置和启动。

## 本云环境运行

```bash
.venv/bin/python tenhou_live.py --config tenhou-room-2456.local.json --setup
.venv/bin/python tenhou_live.py --config tenhou-room-2456.local.json --check
.venv/bin/python tenhou_live.py --config tenhou-room-2456.local.json
```

账号 ID 是登录凭据，保留在自己的配置里，不需要贴进聊天。
对局状态及公开事件、该 AI 自己的动作保存在 `runs/tenhou-live/`，这些记录不自动加入
你的个人训练集。账号 ID 不写入对局日志。没有任何模型读取其他玩家的暗牌。

连接错误或服务器返回错误会立即停止。重连后的 `REINIT` 状态尚不支持，
不能把离线协议验证当作完整在线对战验证。

## 评估范围

三个模型各以 256 个新种子分别比较最终模型、此前保存模型、监督模型，合计
2,304 场评估半庄。AI 使用与对人接口相同的最大概率动作，三个基准对手使用
监督模型随机采样动作；这些场次不参与训练，也不计入 50,000。
较优版本的个人验证集动作一致率：避四 69.85%、平衡 71.21%、争一 71.19%。
较优版本的平均顺位：2.043、1.965、1.902；这些数字只针对该固定基准，
不能换算为天凤段位。六次比较校正后只有争一型的收益差区间完全高于零，
避四和平衡型仍属待验证结果。选择本身也使用了这批验证对局，最终牌谱测试集
继续封存。完整结果见 `runs/rl-50000-evaluation/report.json`。

网关原项目：https://github.com/tomohxx/mjai-gateway （MIT 许可，见 vendor 目录）。
