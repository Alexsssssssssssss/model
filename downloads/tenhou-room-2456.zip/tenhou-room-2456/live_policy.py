"""Online inference from each player's own observation and the full legal action mask."""
import numpy as np
import torch
import json
from pathlib import Path
from policy import Policy

def preferred_checkpoint(path):
    path=Path(path)
    marker=path.parent/'preferred-checkpoint.json'
    if marker.exists():
        selected=Path(json.loads(marker.read_text())['checkpoint'])
        if not selected.is_absolute():selected=marker.parent/selected
        if selected.is_file():return selected
    return path

def tensors(obs):
    seat=obs.player_id
    if any(hand for i,hand in enumerate(obs.hands) if i!=seat):
        raise ValueError('Concealed opponent hand reached an AI')
    assert obs.action_space_size==82
    actions={}
    for a in obs.legal_actions():actions.setdefault(a.encode(),[]).append(a)
    assert actions
    mask=np.zeros(82,dtype=np.bool_);mask[list(actions)]=True
    x=np.frombuffer(obs.encode_extended(),dtype=np.float32).reshape(215,34).copy()
    assert np.isfinite(x).all()
    return x,mask,actions

def resolve(obs,actions,label):
    legal=actions[int(label)]
    # Equal copies of the same discard encode identically. Prefer the just
    # drawn copy when it is available, using only the player's visible hand.
    if label<=36 and not obs.forced_tedashi:
        own=obs.hands[obs.player_id]
        if own:
            for a in legal:
                if a.tile==own[-1]:return a
    return legal[0]

def load_policy(path):
    saved=torch.load(path,map_location='cpu',weights_only=True)
    assert saved['encoding']=='riichienv-0.4.10-215x34-82'
    model=Policy();model.load_state_dict(saved['policy']);model.eval()
    assert all(torch.isfinite(p).all() for p in model.parameters())
    return model

def choose(model,obs,stochastic=False):
    x,mask,actions=tensors(obs)
    if mask.sum()==1:return resolve(obs,actions,np.flatnonzero(mask)[0])
    with torch.no_grad():
        logits=model(torch.from_numpy(x)[None],torch.from_numpy(mask)[None])[0]
        label=torch.distributions.Categorical(logits=logits).sample().item() if stochastic else logits.argmax().item()
    assert mask[label]
    return resolve(obs,actions,label)
